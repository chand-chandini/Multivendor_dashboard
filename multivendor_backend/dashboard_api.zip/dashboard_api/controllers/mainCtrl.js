var sqldb = require('../../config/dbconnect');
var dbutil = require(appRoot + '/utils/dbutils');
var jwt = require('jsonwebtoken');

var JWT_SECRET = process.env.MV_ADMIN_JWT_SECRET || 'mv-admin-dev-secret';
var JWT_EXPIRY = '12h';

// Standalone module path mapping (modules without sub-modules)
var MODULE_PATH_MAP = {
    'Dashboard': '/dashboard',
    'Locations': '/masters/locations',
    'Categories': '/masters/categories',
    'Vendors': '/masters/vendors',
    'Products': '/masters/products',
    'Orders': '/masters/orders',
    'Customers': '/masters/customers',
    'Settlements': '/masters/vendorsettlements',
    'Settings': '/masters/settings',
    'Dev Support': '/masters/devsupport',
    'Permissions': '/permission/permissions'
};

// ---------------------------------------------------------------------------
// Small value helpers used by the write endpoints. They exist so an absent or
// blank body field becomes a proper NULL / default instead of `undefined`,
// which the mysql driver would otherwise reject or coerce unpredictably.
// ---------------------------------------------------------------------------
function num(value, fallback) {
    if (value === undefined || value === null || value === '') return fallback;
    var n = Number(value);
    return isNaN(n) ? fallback : n;
}

function nullableNum(value) {
    if (value === undefined || value === null || value === '') return null;
    var n = Number(value);
    return isNaN(n) ? null : n;
}

function emptyToNull(value) {
    if (value === undefined || value === null || value === '') return null;
    return value;
}

// =============================================
// AUTH / LOGIN
// =============================================

// POST /getUserData — Login
exports.getUserData = function (req, res) {
    var mobile_number = req.body.number || req.body.mobile_number;
    var pwd = req.body.password || req.body.pwd;

    if (!mobile_number || !pwd) {
        return res.json({ status: 202, message: 'Mobile number and password are required' });
    }

    var QRY = 'SELECT * FROM admin_users_t WHERE mobile_number = ? AND d_in = 0';
    dbutil.sqlinjection(sqldb.MySQLConPool, QRY, [mobile_number], 'getUserData-findUser', function (err, rows) {
        if (err) {
            return res.json({ status: 500, message: 'Internal server error' });
        }
        if (!rows || rows.length === 0) {
            return res.json({ status: 202, message: 'Invalid Credentials' });
        }

        var user = rows[0];
        if (user.pwd !== pwd) {
            return res.json({ status: 202, message: 'Invalid Credentials' });
        }

        var token = jwt.sign(
            { admin_id: user.id, tenant_id: user.tenant_id, mobile: user.mobile_number, admin_type: user.designation },
            JWT_SECRET,
            { expiresIn: JWT_EXPIRY }
        );

        // Build menu tree, then fetch tenant info
        buildMenuTree(user.id, user.tenant_id, function (menuErr, menuTree, permissions) {
            if (menuErr) {
                return res.json({ status: 500, message: 'Error loading modules' });
            }

            // Fetch tenant settings and branding
            fetchTenantInfo(user.tenant_id, function (tenantErr, tenantInfo) {
                delete user.pwd;
                return res.json({
                    status: 200,
                    usr_data: [user],
                    data: menuTree,
                    permissions: permissions || [],
                    token: token,
                    tenant: tenantInfo || { name: '', settings: {}, branding: {} }
                });
            });
        });
    });
};
// POST /updatetheme — Update logged-in user's theme color
exports.updatetheme = function (req, res) {
    var user_id = req.admin.id;
    var theme_color = req.body.theme_color;

    if (!theme_color) {
        return res.json({
            status: 202,
            message: 'Theme color is required'
        });
    }

    var QRY = 'UPDATE admin_users_t SET theme_color = ? WHERE id = ? AND tenant_id = ?';

    dbutil.sqlinjection(
        sqldb.MySQLConPool,
        QRY,
        [theme_color, user_id, req.admin.tenant_id],
        'updatetheme',
        function (err) {
            if (err) {
                return res.json({
                    status: 500,
                    message: 'Internal server error'
                });
            }

            return res.json({
                status: 200,
                message: 'Theme color updated successfully',
                theme_color: theme_color
            });
        }
    );
};
// POST /updatelogo — Update logged-in user's personal logo and website name
exports.updatelogo = function (req, res) {
    var user_id = req.admin.id;
    var profile_image = req.body.profile_image;
    var website_name = req.body.website_name;

    if (!profile_image && !website_name) {
        return res.json({
            status: 202,
            message: 'Logo or website name is required'
        });
    }

    var QRY = `
        UPDATE admin_users_t
        SET profile_image = ?, website_name = ?
        WHERE id = ? AND tenant_id = ?
    `;

    dbutil.sqlinjection(
        sqldb.MySQLConPool,
        QRY,
        [profile_image, website_name, user_id, req.admin.tenant_id],
        'updatelogo',
        function (err) {
            if (err) {
                return res.json({
                    status: 500,
                    message: 'Internal server error'
                });
            }

            return res.json({
                status: 200,
                message: 'Logo and website name updated successfully',
                profile_image: profile_image,
                website_name: website_name
            });
        }
    );
};

// Fetch tenant settings + branding for theming
function fetchTenantInfo(tenantId, callback) {
    var QRY = "SELECT t.tenant_name, ts.currency_code, ts.currency_symbol, ts.timezone, ts.primary_color, ts.secondary_color, " +
        "ts.default_language, ts.support_email, ts.support_phone " +
        "FROM tenants t LEFT JOIN tenant_settings ts ON ts.tenant_id = t.id " +
        "WHERE t.id = ? AND IFNULL(t.d_in,0) = 0";

    dbutil.sqlinjection(sqldb.MySQLConPool, QRY, [tenantId], 'fetchTenantInfo-settings', function (err, settingsRows) {
        if (err || !settingsRows || settingsRows.length === 0) {
            return callback(err, { name: '', settings: {}, branding: {} });
        }

        var row = settingsRows[0];
        var tenantName = row.tenant_name;
        var settings = {
            currency_code: row.currency_code,
            currency_symbol: row.currency_symbol,
            timezone: row.timezone,
            primary_color: row.primary_color,
            secondary_color: row.secondary_color,
            default_language: row.default_language,
            support_email: row.support_email,
            support_phone: row.support_phone
        };
var brandQRY = "SELECT logo_light, logo_dark, logo_icon, login_bg_image, favicon, primary_color, secondary_color, " +
    "sidebar_color, header_color, button_color, font_family, custom_css " +
    "FROM tenant_branding WHERE tenant_id = ? AND brand_scope = 'admin_dashboard' AND IFNULL(d_in,0) = 0";

        dbutil.sqlinjection(sqldb.MySQLConPool, brandQRY, [tenantId], 'fetchTenantInfo-branding', function (err2, brandRows) {
            var branding = {};
            if (!err2 && brandRows && brandRows.length > 0) {
                branding = brandRows[0];
            }

            callback(null, {
                name: tenantName,
                settings: settings,
                branding: branding
            });
        });
    });
}

// GET /getloginbranding — public. Branding for the sign-in page, before a user
// has any token. The tenant is resolved from the host the dashboard is served
// on (tenant_domains.custom_domain, or the left-most label against
// tenant_domains.subdomain); `?tenant=` accepts a tenant code or id so a
// non-white-label host such as localhost can still be pointed at a tenant.
// Returns status 204 when nothing matches, which tells the dashboard to fall
// back to its own default branding.
exports.getloginbranding = function (req, res) {
    var host = String(req.query.host || req.hostname || '').toLowerCase().trim();
    host = host.replace(/^https?:\/\//, '').replace(/:\d+$/, '').replace(/\/.*$/, '');
    var tenantRef = req.query.tenant ? String(req.query.tenant).trim() : '';
    var label = host.split('.')[0];

    var QRY, params;
    if (tenantRef) {
        QRY = "SELECT t.id FROM tenants t WHERE IFNULL(t.d_in,0) = 0 AND (t.tenant_unique_code = ? OR t.id = ?) LIMIT 1";
        params = [tenantRef, Number(tenantRef) || 0];
    } else {
        QRY = "SELECT d.tenant_id AS id FROM tenant_domains d " +
            "INNER JOIN tenants t ON t.id = d.tenant_id AND IFNULL(t.d_in,0) = 0 " +
            "WHERE IFNULL(d.d_in,0) = 0 AND (d.custom_domain = ? OR d.subdomain = ? OR d.subdomain = ?) " +
            "ORDER BY d.is_primary DESC, d.id LIMIT 1";
        params = [host, host, label];
    }

    dbutil.sqlinjection(sqldb.MySQLConPool, QRY, params, 'getloginbranding-resolve', function (err, rows) {
        if (err) return res.json({ status: 500, message: 'Internal server error' });
        if (!rows || rows.length === 0) {
            return res.json({ status: 204, message: 'No tenant branding for this host' });
        }

        fetchTenantInfo(rows[0].id, function (infoErr, info) {
            if (infoErr || !info) return res.json({ status: 204, message: 'No tenant branding for this host' });
            // Only what the sign-in page needs; no settings or credentials.
            return res.json({
                status: 200,
                data: {
                    tenant_id: rows[0].id,
                    name: info.name,
                    branding: info.branding || {}
                }
            });
        });
    });
};

// Build sidebar menu tree for a tenant admin user
function buildMenuTree(userId, tenantId, callback) {
    // Step 1: Get ALL modules the user has permission to view (with the CRUD flags)
    var permQry = "SELECT p.admin_main_module_id, p.admin_sub_module_id, p.can_view, p.can_add, p.can_edit, p.can_delete " +
        "FROM admin_user_permissions p WHERE p.admin_users_t_id = ? AND p.can_view = 1 AND IFNULL(p.d_in,0) = 0";

    dbutil.sqlinjection(sqldb.MySQLConPool, permQry, [userId], 'buildMenuTree-perms', function (err, perms) {
        if (err) return callback(err, null, null);

        if (!perms || perms.length === 0) return callback(null, [], []);

        // Collect allowed module IDs and sub-module IDs
        var allowedModuleIds = [];
        var allowedSubModuleIds = [];
        var permMap = {};
        var flatPermissions = [];

        function permKey(moduleId, subId) {
            return String(moduleId) + ':' + (subId === null || subId === undefined ? '0' : String(subId));
        }

        for (var p = 0; p < perms.length; p++) {
            var perm = perms[p];
            if (allowedModuleIds.indexOf(perm.admin_main_module_id) === -1) {
                allowedModuleIds.push(perm.admin_main_module_id);
            }
            if (perm.admin_sub_module_id) {
                allowedSubModuleIds.push(perm.admin_sub_module_id);
            }
            permMap[permKey(perm.admin_main_module_id, perm.admin_sub_module_id)] = {
                can_view: perm.can_view ? 1 : 0,
                can_add: perm.can_add ? 1 : 0,
                can_edit: perm.can_edit ? 1 : 0,
                can_delete: perm.can_delete ? 1 : 0
            };
        }

        // Step 2: Get modules + their sub-modules
        var modPlaceholders = allowedModuleIds.map(function () { return '?'; }).join(',');
        var QRY = "SELECT m.id, m.module_name, m.module_icon, m.module_order, " +
            "s.id AS sub_id, s.sub_module_name, s.route_path, s.sub_module_order " +
            "FROM admin_main_module m " +
            "LEFT JOIN admin_sub_module s ON s.admin_main_module_id = m.id AND s.is_active = 1 AND IFNULL(s.d_in,0) = 0 " +
            "WHERE m.id IN (" + modPlaceholders + ") AND m.is_active = 1 AND IFNULL(m.d_in,0) = 0 " +
            "ORDER BY m.module_order, s.sub_module_order";

        dbutil.sqlinjection(sqldb.MySQLConPool, QRY, allowedModuleIds, 'buildMenuTree-modules', function (err2, rows) {
            if (err2) return callback(err2, null, null);

            var modulesMap = {};
            var modulesList = [];

            for (var i = 0; i < rows.length; i++) {
                var row = rows[i];
                if (!modulesMap[row.id]) {
                    var modulePath = MODULE_PATH_MAP[row.module_name] || null;
                    var modulePerm = permMap[permKey(row.id, null)] || { can_view: 1, can_add: 0, can_edit: 0, can_delete: 0 };
                    var moduleItem = {
                        id: row.id,
                        title: row.module_name,
                        path: modulePath,
                        icon: row.module_icon,
                        active: false,
                        type: 'sub',
                        level: 1,
                        can_view: modulePerm.can_view,
                        can_add: modulePerm.can_add,
                        can_edit: modulePerm.can_edit,
                        can_delete: modulePerm.can_delete,
                        children: []
                    };
                    modulesMap[row.id] = moduleItem;
                    modulesList.push(moduleItem);

                    if (modulePath) {
                        flatPermissions.push({
                            module_id: row.id,
                            sub_module_id: null,
                            module_name: row.module_name,
                            sub_module_name: null,
                            path: modulePath,
                            can_view: modulePerm.can_view,
                            can_add: modulePerm.can_add,
                            can_edit: modulePerm.can_edit,
                            can_delete: modulePerm.can_delete
                        });
                    }
                }

                // Only add sub-module if user has permission for it
                if (row.sub_id && allowedSubModuleIds.indexOf(row.sub_id) !== -1) {
                    var subPerm = permMap[permKey(row.id, row.sub_id)] || { can_view: 1, can_add: 0, can_edit: 0, can_delete: 0 };
                    modulesMap[row.id].children.push({
                        parent_id: row.id,
                        sub_id: row.sub_id,
                        title: row.sub_module_name,
                        path: row.route_path,
                        type: 'link',
                        level: 2,
                        can_view: subPerm.can_view,
                        can_add: subPerm.can_add,
                        can_edit: subPerm.can_edit,
                        can_delete: subPerm.can_delete
                    });

                    flatPermissions.push({
                        module_id: row.id,
                        sub_module_id: row.sub_id,
                        module_name: row.module_name,
                        sub_module_name: row.sub_module_name,
                        path: row.route_path,
                        can_view: subPerm.can_view,
                        can_add: subPerm.can_add,
                        can_edit: subPerm.can_edit,
                        can_delete: subPerm.can_delete
                    });
                }
            }
            callback(null, modulesList, flatPermissions);
        });
    });
}

// =============================================
// MODULE / PERMISSION ENDPOINTS
// =============================================

// POST /getmodulelistdetails — Get all modules/submodules with user permissions
exports.getmodulelistdetails = function (req, res) {
    var usr_id = req.body.usr_id;
    if (!usr_id) {
        return res.json({ status: 202, message: 'User ID is required' });
    }
    buildMenuTree(usr_id, req.admin.tenant_id, function (err, menuTree, permissions) {
        if (err) return res.json({ status: 500, message: 'Internal server error' });
        return res.json({ status: 200, data: menuTree, permissions: permissions || [] });
    });
};

// POST /submituserslogin — Add a new admin user with module permissions
exports.submituserslogin = function (req, res) {
    var b = req.body;
    var tenant_id = req.admin.tenant_id;
    var name = b.name;
    var number = b.number || b.mobile_number;
    var email = b.email || '';
    var pwd = b.pwd;
    var designation = b.designation || '';

    if (!name || !number || !pwd) {
        return res.json({ status: 202, message: 'Name, mobile number and password are required' });
    }

    var checkQry = 'SELECT id FROM admin_users_t WHERE mobile_number = ? AND tenant_id = ? AND d_in = 0';
    dbutil.sqlinjection(sqldb.MySQLConPool, checkQry, [number, tenant_id], 'submituserslogin-check', function (err, rows) {
        if (err) return res.json({ status: 500, message: 'Internal server error' });
        if (rows && rows.length > 0) {
            return res.json({ status: 300, message: 'Mobile number already exists' });
        }

        var insertQry = "INSERT INTO admin_users_t (tenant_id, name, mobile_number, email, pwd, designation, login_status, i_ts) VALUES (?, ?, ?, ?, ?, ?, 0, NOW())";
        dbutil.sqlinjection(sqldb.MySQLConPool, insertQry, [tenant_id, name, number, email, pwd, designation], 'submituserslogin-insert', function (err, result) {
            if (err) return res.json({ status: 500, message: 'Internal server error' });

            var newUserId = result.insertId;
            var selectedModules = b.selectedmoduleslist;
            if (selectedModules && selectedModules.length > 0) {
                saveUserPermissions(newUserId, selectedModules, function () {
                    return res.json({ status: 200, message: 'User created successfully' });
                });
            } else {
                return res.json({ status: 200, message: 'User created successfully' });
            }
        });
    });
};

// Helper: save permissions from the selectedmoduleslist array
function saveUserPermissions(userId, modules, callback) {
    var deleteQry = 'DELETE FROM admin_user_permissions WHERE admin_users_t_id = ?';
    dbutil.sqlinjection(sqldb.MySQLConPool, deleteQry, [userId], 'savePerms-delete', function (err) {
        if (err || !modules || modules.length === 0) return callback();

        var values = [];
        var placeholders = [];
        var seen = {};

        // Per-action flags are optional: callers that only select modules keep
        // the original behaviour of granting full access.
        function flag(value) {
            if (value === undefined || value === null) return 1;
            return (value === 1 || value === '1' || value === true) ? 1 : 0;
        }

        for (var i = 0; i < modules.length; i++) {
            var m = modules[i];
            // For standalone modules (id > 10000 offset, or id == module_id with no link), sub_module_id is NULL
            var subModuleId = (m.id > 10000 || (m.id == m.module_id && !m.link)) ? null : (m.id || null);
            var key = m.module_id + '-' + subModuleId;
            if (seen[key]) continue; // avoid duplicates
            seen[key] = true;
            placeholders.push('(?, ?, ?, ?, ?, ?, ?, NOW())');
            values.push(userId, m.module_id, subModuleId, flag(m.can_view), flag(m.can_add), flag(m.can_edit), flag(m.can_delete));
        }

        if (placeholders.length === 0) return callback();

        var insertQry = 'INSERT INTO admin_user_permissions (admin_users_t_id, admin_main_module_id, admin_sub_module_id, can_view, can_add, can_edit, can_delete, i_ts) VALUES ' + placeholders.join(', ');
        dbutil.sqlinjection(sqldb.MySQLConPool, insertQry, values, 'savePerms-insert', function () {
            callback();
        });
    });
}

// GET /getuserlist — Get all admin users for this tenant
exports.getuserlist = function (req, res) {
    var tenant_id = req.admin.tenant_id;
    var QRY = "SELECT id, tenant_id, name, mobile_number AS number, email, profile_image, designation, login_status, pwd, i_ts FROM admin_users_t WHERE tenant_id = ? AND d_in = 0";
    dbutil.sqlinjection(sqldb.MySQLConPool, QRY, [tenant_id], 'getuserlist', function (err, rows) {
        if (err) return res.json({ status: 500, message: 'Internal server error' });
        return res.json({ status: 200, data: rows });
    });
};

// POST /getupdatemodules — FETCH module list with check_sub_menu flags for a user
exports.getupdatemodules = function (req, res) {
    var usr_id = req.body.usr_id || 0;

    // Get modules WITH sub-modules
    var subQry = "SELECT m.id AS module_id, m.module_name AS module_nm, m.module_icon AS icon, m.module_order, " +
        "s.id, s.sub_module_name AS label, s.route_path AS link, s.sub_module_order, " +
        "CASE WHEN p.id IS NOT NULL THEN 1 ELSE 0 END AS check_sub_menu, " +
        "IFNULL(p.can_view,1) AS can_view, IFNULL(p.can_add,1) AS can_add, IFNULL(p.can_edit,1) AS can_edit, IFNULL(p.can_delete,1) AS can_delete, " +
        "IFNULL(m.d_in,0) AS d_in " +
        "FROM admin_main_module m " +
        "INNER JOIN admin_sub_module s ON s.admin_main_module_id = m.id AND s.is_active = 1 AND IFNULL(s.d_in,0) = 0 " +
        "LEFT JOIN admin_user_permissions p ON p.admin_main_module_id = m.id AND p.admin_sub_module_id = s.id " +
        "AND p.admin_users_t_id = ? AND IFNULL(p.d_in,0) = 0 " +
        "WHERE m.is_active = 1 AND IFNULL(m.d_in,0) = 0";

    // Get standalone modules (no sub-modules) — use (m.id + 10000) as id to avoid collision with sub_module IDs
    var standaloneQry = "SELECT m.id AS module_id, m.module_name AS module_nm, m.module_icon AS icon, m.module_order, " +
        "(m.id + 10000) AS id, m.module_name AS label, NULL AS link, 0 AS sub_module_order, " +
        "CASE WHEN p.id IS NOT NULL THEN 1 ELSE 0 END AS check_sub_menu, " +
        "IFNULL(p.can_view,1) AS can_view, IFNULL(p.can_add,1) AS can_add, IFNULL(p.can_edit,1) AS can_edit, IFNULL(p.can_delete,1) AS can_delete, " +
        "IFNULL(m.d_in,0) AS d_in " +
        "FROM admin_main_module m " +
        "LEFT JOIN admin_user_permissions p ON p.admin_main_module_id = m.id AND p.admin_sub_module_id IS NULL " +
        "AND p.admin_users_t_id = ? AND IFNULL(p.d_in,0) = 0 " +
        "WHERE m.is_active = 1 AND IFNULL(m.d_in,0) = 0 " +
        "AND m.id NOT IN (SELECT DISTINCT admin_main_module_id FROM admin_sub_module WHERE is_active = 1 AND IFNULL(d_in,0) = 0)";

    dbutil.sqlinjection(sqldb.MySQLConPool, subQry, [usr_id], 'getupdatemodules-sub', function (err, subRows) {
        if (err) return res.json({ status: 500, message: 'Internal server error' });

        dbutil.sqlinjection(sqldb.MySQLConPool, standaloneQry, [usr_id], 'getupdatemodules-standalone', function (err2, standaloneRows) {
            if (err2) standaloneRows = [];

            var allRows = (subRows || []).concat(standaloneRows || []);
            // Sort by module_order then sub_module_order
            allRows.sort(function (a, b) {
                if (a.module_order !== b.module_order) return a.module_order - b.module_order;
                return (a.sub_module_order || 0) - (b.sub_module_order || 0);
            });

            for (var i = 0; i < allRows.length; i++) {
                allRows[i].check_sub_menu = allRows[i].check_sub_menu === 1;
            }

            return res.json({ status: 200, data: allRows });
        });
    });
};

// POST /deleteuser — Soft delete users (tenant-scoped)
// Hard delete. The admin_user_permissions rows belong to the user rather than
// being independent data, so they are removed first to avoid orphan rows.
exports.deleteuser = function (req, res) {
    var tenant_id = req.admin.tenant_id;
    var ids = req.body;
    if (!Array.isArray(ids)) {
        ids = req.body.user_id ? [req.body.user_id] : [req.body.id];
    }
    ids = (ids || []).filter(function (x) { return x !== undefined && x !== null && x !== ''; });
    if (!ids.length) {
        return res.json({ status: 202, message: 'User ID is required' });
    }

    var placeholders = ids.map(function () { return '?'; }).join(',');

    var PERM_QRY = 'DELETE p FROM admin_user_permissions p ' +
        'INNER JOIN admin_users_t u ON u.id = p.admin_users_t_id ' +
        'WHERE p.admin_users_t_id IN (' + placeholders + ') AND u.tenant_id = ?';

    dbutil.sqlinjection(sqldb.MySQLConPool, PERM_QRY, ids.concat([tenant_id]), 'deleteuser-permissions', function (permErr) {
        if (permErr) {
            console.log('DELETE USER PERMISSIONS ERROR:', permErr);
            return res.json({ status: 500, message: 'Internal server error' });
        }

        var QRY = 'DELETE FROM admin_users_t WHERE id IN (' + placeholders + ') AND tenant_id = ?';
        dbutil.sqlinjection(sqldb.MySQLConPool, QRY, ids.concat([tenant_id]), 'deleteuser', function (err, result) {
            if (err) {
                console.log('DELETE USER ERROR:', err);
                return res.json({ status: 500, message: 'Internal server error' });
            }
            if (!result || !result.affectedRows) {
                return res.json({ status: 202, message: 'User not found' });
            }
            return res.json({ status: 200, message: 'User deleted successfully', affectedRows: result.affectedRows });
        });
    });
};

// POST /postusermenulist — Save menu/module list for a user (from edit modal)
exports.postusermenulist = function (req, res) {
    var modules = req.body.modules;
    var details = req.body.employeeDetails;
    var tenant_id = req.admin.tenant_id;

    if (!modules || !Array.isArray(modules) || modules.length === 0) {
        return res.json({ status: 202, message: 'Modules list is required' });
    }

    var usr_id = modules[0].user_id;
    if (!usr_id) {
        return res.json({ status: 202, message: 'User ID is required' });
    }

    // Update user details if provided (tenant-scoped)
    if (details) {
        var updateParts = [];
        var updateParams = [];
        if (details.name) { updateParts.push('name = ?'); updateParams.push(details.name); }
        if (details.number) { updateParts.push('mobile_number = ?'); updateParams.push(details.number); }
        if (details.email) { updateParts.push('email = ?'); updateParams.push(details.email); }
        if (details.pwd) { updateParts.push('pwd = ?'); updateParams.push(details.pwd); }
        if (details.designation) { updateParts.push('designation = ?'); updateParams.push(details.designation); }

        if (updateParts.length > 0) {
            updateParams.push(usr_id);
            updateParams.push(tenant_id);
            var updateQry = 'UPDATE admin_users_t SET ' + updateParts.join(', ') + ' WHERE id = ? AND tenant_id = ?';
            dbutil.sqlinjection(sqldb.MySQLConPool, updateQry, updateParams, 'postusermenulist-updateUser', function () { });
        }
    }

    // Save permissions
    saveUserPermissions(usr_id, modules, function () {
        return res.json({ status: 200, message: 'Permissions updated successfully' });
    });
};

// POST /getusersprofile — Get user profile by user_id (tenant-scoped)
exports.getusersprofile = function (req, res) {
    var tenant_id = req.admin.tenant_id;
    var user_ids = req.body.user_id;
    if (!user_ids) return res.json({ status: 202, message: 'User ID is required' });
    if (!Array.isArray(user_ids)) user_ids = [user_ids];

    var placeholders = user_ids.map(function () { return '?'; }).join(',');
    var params = user_ids.concat([tenant_id]);
    var QRY = "SELECT id, name, mobile_number, email, profile_image, designation FROM admin_users_t WHERE id IN (" + placeholders + ") AND tenant_id = ? AND d_in = 0";
    dbutil.sqlinjection(sqldb.MySQLConPool, QRY, params, 'getusersprofile', function (err, rows) {
        if (err) return res.json({ status: 500, message: 'Internal server error' });
        return res.json({ status: 200, data: rows });
    });
};

// POST /updateuserpassword — Update user password (tenant-scoped)
exports.updateuserpassword = function (req, res) {
    var tenant_id = req.admin.tenant_id;
    var user_id = req.body.user_id;
    var new_password = req.body.new_password;
    if (!user_id || !new_password) return res.json({ status: 202, message: 'User ID and new password are required' });

    var QRY = 'UPDATE admin_users_t SET pwd = ? WHERE id = ? AND tenant_id = ?';
    dbutil.sqlinjection(sqldb.MySQLConPool, QRY, [new_password, user_id, tenant_id], 'updateuserpassword', function (err) {
        if (err) return res.json({ status: 500, message: 'Internal server error' });
        return res.json({ status: 200, message: 'Password updated successfully' });
    });
};

// GET /getmasterdata1 — Return empty arrays (keeps frontend from breaking)
exports.getmasterdata1 = function (req, res) {
    return res.json({ status: 200, data: [[], [], [], []] });
};

// =============================================
// DASHBOARD
// =============================================

// GET /getDashboard — Dashboard summary counts (tenant-scoped)
exports.getDashboard = function (req, res) {
    var tenant_id = req.admin.tenant_id;
    var QRY = "SELECT " +
        "(SELECT COUNT(*) FROM locations WHERE tenant_id = ? AND IFNULL(d_in,0) = 0) AS location_count, " +
        "(SELECT COUNT(*) FROM categories WHERE tenant_id = ? AND IFNULL(d_in,0) = 0) AS category_count, " +
        "(SELECT COUNT(*) FROM vendors WHERE tenant_id = ? AND IFNULL(d_in,0) = 0) AS vendor_count, " +
        "(SELECT COUNT(*) FROM dev_support_tickets WHERE IFNULL(d_in,0) = 0) AS total_tickets";

    dbutil.sqlinjection(sqldb.MySQLConPool, QRY, [tenant_id, tenant_id, tenant_id], 'getDashboard', function (err, rows) {
        if (err) return res.json({ status: 500, message: 'Internal server error' });
        return res.json({ status: 200, data: rows[0] || {} });
    });
};

// =============================================
// LOCATIONS
// =============================================

// POST /addlocation
exports.addlocation = function (req, res) {
    var b = req.body;
    var tenant_id = req.admin.tenant_id;
  console.log('========== ADD LOCATION ==========');
console.log('BODY:', req.body);
console.log('FILE:', req.file);
console.log('==================================');
if (req.file) {
    b.location_image = '/uploads/' + req.file.filename;
}
    var QRY = "INSERT INTO locations (tenant_id, city, area, pincode, state, country, latitude, longitude, location_image, max_delivery_service_km, active_status, i_ts) " +
        "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, NOW())";
    var params = [
        tenant_id, b.city || '', b.area || '', b.pincode || '', b.state || '', b.country || '',
        b.latitude || null, b.longitude || null, b.location_image || null, b.max_delivery_service_km || 0
    ];

    dbutil.sqlinjection(sqldb.MySQLConPool, QRY, params, 'addlocation', function (err, result) {
        if (err) return res.json({ status: 500, message: 'Internal server error' });
        return res.json({ status: 200, message: 'Location added successfully', insertId: result.insertId });
    });
};

// GET /getlocation
exports.getlocation = function (req, res) {
    var tenant_id = req.admin.tenant_id;
    var QRY = "SELECT * FROM locations WHERE tenant_id = ? AND IFNULL(d_in,0) = 0 ORDER BY i_ts DESC";
    dbutil.sqlinjection(sqldb.MySQLConPool, QRY, [tenant_id], 'getlocation', function (err, rows) {
if (err) {
    console.error('getlocation DB error:', err);
    return res.json({ status: 500, message: 'Internal server error' });
}
        return res.json({ status: 200, data: rows });
    });
};

// POST /updatelocation
exports.updatelocation = function (req, res) {
    var b = req.body;
    var tenant_id = req.admin.tenant_id;

    console.log('========== UPDATE LOCATION ==========');
    console.log('BODY:', req.body);
    console.log('FILE:', req.file);
    console.log('=====================================');

    if (!b.id) {
        return res.json({
            status: 202,
            message: 'Location ID is required'
        });
    }

    // If a new image is uploaded, use the new image path.
    // Otherwise, keep the existing image from the database.
    if (req.file) {

        b.location_image = '/uploads/' + req.file.filename;

        var QRY = "UPDATE locations SET city = ?, area = ?, pincode = ?, state = ?, country = ?, " +
            "latitude = ?, longitude = ?, location_image = ?, max_delivery_service_km = ?, active_status = ? " +
            "WHERE id = ? AND tenant_id = ?";

        var params = [
            b.city || '',
            b.area || '',
            b.pincode || '',
            b.state || '',
            b.country || '',
            b.latitude || null,
            b.longitude || null,
            b.location_image,
            b.max_delivery_service_km || 0,
            b.active_status != null ? b.active_status : 1,
            b.id,
            tenant_id
        ];

        dbutil.sqlinjection(
            sqldb.MySQLConPool,
            QRY,
            params,
            'updatelocation',
            function (err) {

                if (err) {
                    console.log('UPDATE LOCATION ERROR:', err);

                    return res.json({
                        status: 500,
                        message: 'Internal server error'
                    });
                }

                return res.json({
                    status: 200,
                    message: 'Location updated successfully'
                });
            }
        );

    } else {

        // No new image selected.
        // Update the other fields without changing the existing image.

        var QRY = "UPDATE locations SET city = ?, area = ?, pincode = ?, state = ?, country = ?, " +
            "latitude = ?, longitude = ?, max_delivery_service_km = ?, active_status = ? " +
            "WHERE id = ? AND tenant_id = ?";

        var params = [
            b.city || '',
            b.area || '',
            b.pincode || '',
            b.state || '',
            b.country || '',
            b.latitude || null,
            b.longitude || null,
            b.max_delivery_service_km || 0,
            b.active_status != null ? b.active_status : 1,
            b.id,
            tenant_id
        ];

        dbutil.sqlinjection(
            sqldb.MySQLConPool,
            QRY,
            params,
            'updatelocation',
            function (err) {

                if (err) {
                    console.log('UPDATE LOCATION ERROR:', err);

                    return res.json({
                        status: 500,
                        message: 'Internal server error'
                    });
                }

                return res.json({
                    status: 200,
                    message: 'Location updated successfully'
                });
            }
        );
    }
};

// POST /deletelocation
// Hard delete, refused while anything still points at the location, so removing
// a row can never leave vendors, partners, banners or coupons dangling.
exports.deletelocation = function (req, res) {
    var tenant_id = req.admin.tenant_id;
    var id = req.body.id;
    if (!id) return res.json({ status: 202, message: 'Location ID is required' });

    var CHECK_QRY = "SELECT " +
        "(SELECT COUNT(*) FROM locations WHERE id = ? AND tenant_id = ?) AS found, " +
        "(SELECT COUNT(*) FROM vendors WHERE location_id = ? AND IFNULL(d_in,0) = 0) AS vendors, " +
        "(SELECT COUNT(*) FROM delivery_partners WHERE location_id = ? AND IFNULL(d_in,0) = 0) AS delivery_partners, " +
        "(SELECT COUNT(*) FROM banners WHERE location_id = ? AND IFNULL(d_in,0) = 0) AS banners, " +
        "(SELECT COUNT(*) FROM coupons WHERE location_id = ? AND IFNULL(d_in,0) = 0) AS coupons";

    dbutil.sqlinjection(sqldb.MySQLConPool, CHECK_QRY, [id, tenant_id, id, id, id, id], 'deletelocation-check', function (err, rows) {
        if (err) return res.json({ status: 500, message: 'Internal server error' });
        var r = rows && rows[0];
        if (!r || !r.found) return res.json({ status: 202, message: 'Location not found' });

        var usage = [];
        if (r.vendors) usage.push(r.vendors + ' vendor(s)');
        if (r.delivery_partners) usage.push(r.delivery_partners + ' delivery partner(s)');
        if (r.banners) usage.push(r.banners + ' banner(s)');
        if (r.coupons) usage.push(r.coupons + ' coupon(s)');
        if (usage.length) {
            return res.json({ status: 202, message: 'Cannot delete: this location is currently used by ' + usage.join(', ') });
        }

        dbutil.sqlinjection(sqldb.MySQLConPool, 'DELETE FROM locations WHERE id = ? AND tenant_id = ?', [id, tenant_id], 'deletelocation', function (err2, result) {
            if (err2) return res.json({ status: 500, message: 'Internal server error' });
            if (!result || !result.affectedRows) return res.json({ status: 202, message: 'Location not found' });
            return res.json({ status: 200, message: 'Location deleted successfully', affectedRows: result.affectedRows });
        });
    });
};
// POST /updatelocationactivestatus
exports.updatelocationactivestatus = function (req, res) {

    var tenant_id = req.admin.tenant_id;

    var QRY = `
        UPDATE locations
        SET active_status = ?
        WHERE id = ?
          AND tenant_id = ?
    `;

    var params = [
        req.body.value,
        req.body.id,
        tenant_id
    ];

    dbutil.sqlinjection(
        sqldb.MySQLConPool,
        QRY,
        params,
        'updatelocationactivestatus',
        function (err) {

            if (err) {

                console.log('UPDATE LOCATION ACTIVE STATUS ERROR:', err);

                return res.json({
                    status: 500,
                    message: 'Internal server error'
                });
            }

            return res.json({
                status: 200,
                message: 'Location active status updated successfully'
            });
        }
    );
};
// =============================================
// CATEGORIES
// =============================================

// True only for a base64 PNG/JPEG data URL (rejects plain URLs and other text)
function isImageDataUrl(value) {
    return typeof value === 'string' && /^data:image\/(png|jpe?g);base64,/i.test(value);
}

// POST /addcategory
exports.addcategory = function (req, res) {
    var b = req.body;
    var tenant_id = req.admin.tenant_id;

    // Store the uploaded image as its base64 data URL text (e.g. "data:image/png;base64,...").
    // Raw bytes in the utf8mb4 longtext column get corrupted, and URLs must never be stored.
    var categoryImage = isImageDataUrl(b.category_image) ? b.category_image : null;

    var QRY = "INSERT INTO categories " +
        "(tenant_id, parent_id, category_name, category_image, vertical, category_order, is_active, i_ts) " +
        "VALUES (?, NULL, ?, ?, ?, ?, ?, NOW())";

    var params = [
        tenant_id,
        b.category_name || '',
        categoryImage,
        emptyToNull(b.vertical),
        num(b.category_order, 0),
        b.is_active !== undefined ? b.is_active : 1
    ];

    dbutil.sqlinjection(sqldb.MySQLConPool, QRY, params, 'addcategory', function (err, result) {
        if (err) {
            console.log('ADD CATEGORY ERROR:', err);
            return res.json({ status: 500, message: 'Internal server error' });
        }
        return res.json({
            status: 200,
            message: 'Category added successfully',
            insertId: result ? result.insertId : null
        });
    });
};

// POST /updatecategory
exports.updatecategory = function (req, res) {
    var b = req.body;
    var tenant_id = req.admin.tenant_id;

    if (!b.id) return res.json({ status: 202, message: 'Category ID is required' });

    // Image is replaced only when a new image data URL is sent; otherwise the
    // stored image is kept. vertical, category_order and is_active are editable.
    var QRY = "UPDATE categories SET " +
        "category_name = ?, " +
        "category_image = COALESCE(?, category_image), " +
        "vertical = ?, category_order = ?, is_active = ? " +
        "WHERE id = ? AND tenant_id = ?";

    var params = [
        b.category_name || '',
        isImageDataUrl(b.category_image) ? b.category_image : null,
        emptyToNull(b.vertical),
        num(b.category_order, 0),
        b.is_active !== undefined ? b.is_active : 1,
        b.id,
        tenant_id
    ];

    dbutil.sqlinjection(sqldb.MySQLConPool, QRY, params, 'updatecategory', function (err, result) {
        if (err) {
            console.log('UPDATE CATEGORY ERROR:', err);
            return res.json({ status: 500, message: 'Internal server error' });
        }
        if (!result || !result.affectedRows) {
            return res.json({ status: 202, message: 'Category not found' });
        }
        return res.json({ status: 200, message: 'Category updated successfully' });
    });
};
// POST /updatecategoryactivestatus
exports.updatecategoryactivestatus = function (req, res) {
    var tenant_id = req.admin.tenant_id;
    var id = req.body.id;
    var is_active = req.body.is_active;

    if (!id) {
        return res.json({
            status: 202,
            message: 'Category ID is required'
        });
    }

    var QRY = "UPDATE categories SET is_active = ? WHERE id = ? AND tenant_id = ?";

    dbutil.sqlinjection(
        sqldb.MySQLConPool,
        QRY,
        [is_active, id, tenant_id],
        'updatecategoryactivestatus',
        function (err) {
            if (err) {
                return res.json({
                    status: 500,
                    message: 'Internal server error'
                });
            }

            return res.json({
                status: 200,
                message: 'Category status updated successfully'
            });
        }
    );
};
// POST /deletecategory
// Hard delete. A parent category is only removable once nothing references it,
// mirroring the guard deletesubcategory already applies, so removing a row can
// never orphan sub-categories, products, coupons, vendors or filters.
exports.deletecategory = function (req, res) {
    var tenant_id = req.admin.tenant_id;
    var id = req.body.id;
    if (!id) return res.json({ status: 202, message: 'Category ID is required' });

    var CHECK_QRY = "SELECT " +
        "(SELECT COUNT(*) FROM categories c WHERE c.id = ? AND c.tenant_id = ? AND c.parent_id IS NULL) AS found, " +
        "(SELECT COUNT(*) FROM categories WHERE parent_id = ? AND IFNULL(d_in,0) = 0) AS sub_categories, " +
        "(SELECT COUNT(*) FROM products WHERE category_id = ? AND IFNULL(d_in,0) = 0) AS products, " +
        "(SELECT COUNT(*) FROM coupons WHERE category_id = ? AND IFNULL(d_in,0) = 0) AS coupons, " +
        "(SELECT COUNT(*) FROM vendors WHERE category_id = ? AND IFNULL(d_in,0) = 0) AS vendors, " +
        "(SELECT COUNT(*) FROM catalog_filters WHERE category_id = ? AND IFNULL(d_in,0) = 0) AS catalog_filters";

    var checkParams = [id, tenant_id, id, id, id, id, id];

    dbutil.sqlinjection(sqldb.MySQLConPool, CHECK_QRY, checkParams, 'deletecategory-check', function (err, rows) {
        if (err) return res.json({ status: 500, message: 'Internal server error' });
        var r = rows && rows[0];
        if (!r || !r.found) return res.json({ status: 202, message: 'Category not found' });

        var usage = [];
        if (r.sub_categories) usage.push(r.sub_categories + ' sub-category(ies)');
        if (r.products) usage.push(r.products + ' product(s)');
        if (r.coupons) usage.push(r.coupons + ' coupon(s)');
        if (r.vendors) usage.push(r.vendors + ' vendor(s)');
        if (r.catalog_filters) usage.push(r.catalog_filters + ' filter(s)');
        if (usage.length) {
            return res.json({
                status: 202,
                message: 'Cannot delete: this category is currently used by ' + usage.join(', ')
            });
        }

        var QRY = 'DELETE FROM categories WHERE id = ? AND tenant_id = ? AND parent_id IS NULL';
        dbutil.sqlinjection(sqldb.MySQLConPool, QRY, [id, tenant_id], 'deletecategory', function (err2, result) {
            if (err2) return res.json({ status: 500, message: 'Internal server error' });
            if (!result || !result.affectedRows) return res.json({ status: 202, message: 'Category not found' });
            return res.json({
                status: 200,
                message: 'Category deleted successfully',
                affectedRows: result.affectedRows
            });
        });
    });
};

// Checks that parent_id is an active main category (parent_id IS NULL) of this tenant
function checkMainCategory(parent_id, tenant_id, callback) {
    var QRY = "SELECT id FROM categories WHERE id = ? AND tenant_id = ? AND parent_id IS NULL AND IFNULL(d_in,0) = 0";
    dbutil.sqlinjection(sqldb.MySQLConPool, QRY, [parent_id, tenant_id], 'checkMainCategory', function (err, rows) {
        if (err) return callback(err, false);
        return callback(null, rows && rows.length > 0);
    });
}

// POST /addsubcategory
exports.addsubcategory = function (req, res) {
    var b = req.body;
    var tenant_id = req.admin.tenant_id;

    if (!b.parent_id) return res.json({ status: 202, message: 'Parent category ID is required' });

    checkMainCategory(b.parent_id, tenant_id, function (err, isValid) {
        if (err) return res.json({ status: 500, message: 'Internal server error' });
        if (!isValid) return res.json({ status: 202, message: 'Invalid parent category' });

        // Image stored as PNG/JPEG base64 data URL.
        var QRY = "INSERT INTO categories " +
            "(tenant_id, parent_id, category_name, category_image, vertical, category_order, is_active, i_ts) " +
            "VALUES (?, ?, ?, ?, ?, ?, ?, NOW())";
        var params = [
            tenant_id,
            b.parent_id,
            b.category_name || '',
            isImageDataUrl(b.category_image) ? b.category_image : null,
            emptyToNull(b.vertical),
            num(b.category_order, 0),
            b.is_active !== undefined ? b.is_active : 1
        ];

        dbutil.sqlinjection(sqldb.MySQLConPool, QRY, params, 'addsubcategory', function (err2, result) {
            if (err2) return res.json({ status: 500, message: 'Internal server error' });
            return res.json({ status: 200, message: 'Subcategory added successfully', insertId: result.insertId });
        });
    });
};

// GET /getsubcategory
exports.getsubcategory = function (req, res) {
    var tenant_id = req.admin.tenant_id;
    var parent_id = req.query.parent_id;

    var QRY = "SELECT c.*, p.category_name AS parent_category_name " +
        "FROM categories c " +
        "LEFT JOIN categories p ON p.id = c.parent_id " +
        "WHERE c.tenant_id = ? AND c.parent_id IS NOT NULL AND IFNULL(c.d_in,0) = 0";
    var params = [tenant_id];

    if (parent_id) {
        QRY += " AND c.parent_id = ?";
        params.push(parent_id);
    }

    QRY += " ORDER BY c.category_order, c.i_ts DESC";

    dbutil.sqlinjection(sqldb.MySQLConPool, QRY, params, 'getsubcategory', function (err, rows) {
        if (err) return res.json({ status: 500, message: 'Internal server error' });
        return res.json({ status: 200, data: rows });
    });
};

// POST /updatesubcategory
exports.updatesubcategory = function (req, res) {
    var b = req.body;
    var tenant_id = req.admin.tenant_id;

    if (!b.id) return res.json({ status: 202, message: 'Subcategory ID is required' });
    if (!b.parent_id) return res.json({ status: 202, message: 'Parent category ID is required' });

    checkMainCategory(b.parent_id, tenant_id, function (err, isValid) {
        if (err) return res.json({ status: 500, message: 'Internal server error' });
        if (!isValid) return res.json({ status: 202, message: 'Invalid parent category' });

        // Image replaced only when a new data URL is sent.
        var QRY = "UPDATE categories SET " +
            "parent_id = ?, category_name = ?, " +
            "category_image = COALESCE(?, category_image), " +
            "vertical = ?, category_order = ?, is_active = ? " +
            "WHERE id = ? AND tenant_id = ? AND parent_id IS NOT NULL";
        var params = [
            b.parent_id,
            b.category_name || '',
            isImageDataUrl(b.category_image) ? b.category_image : null,
            emptyToNull(b.vertical),
            num(b.category_order, 0),
            b.is_active !== undefined ? b.is_active : 1,
            b.id,
            tenant_id
        ];

        dbutil.sqlinjection(sqldb.MySQLConPool, QRY, params, 'updatesubcategory', function (err2, result) {
            if (err2) return res.json({ status: 500, message: 'Internal server error' });
            if (!result || !result.affectedRows) return res.json({ status: 202, message: 'Subcategory not found' });
            return res.json({ status: 200, message: 'Subcategory updated successfully' });
        });
    });
};

// POST /deletesubcategory
exports.deletesubcategory = function (req, res) {
    var tenant_id = req.admin.tenant_id;
    var id = req.body.id;
    if (!id) return res.json({ status: 202, message: 'Subcategory ID is required' });

    // Block the delete while any active record still uses this subcategory
    var CHECK_QRY = "SELECT " +
        "(SELECT COUNT(*) FROM categories c WHERE c.id = ? AND c.tenant_id = ? AND c.parent_id IS NOT NULL) AS found, " +
        "(SELECT COUNT(*) FROM categories WHERE parent_id = ? AND IFNULL(d_in,0) = 0) AS child_categories, " +
        "(SELECT COUNT(*) FROM products WHERE category_id = ? AND IFNULL(d_in,0) = 0) AS products, " +
        "(SELECT COUNT(*) FROM coupons WHERE category_id = ? AND IFNULL(d_in,0) = 0) AS coupons, " +
        "(SELECT COUNT(*) FROM vendors WHERE category_id = ? AND IFNULL(d_in,0) = 0) AS vendors, " +
        "(SELECT COUNT(*) FROM catalog_filters WHERE category_id = ? AND IFNULL(d_in,0) = 0) AS catalog_filters, " +
        "(SELECT COUNT(*) FROM category_attributes WHERE category_id = ? AND IFNULL(d_in,0) = 0) AS category_attributes";
    var checkParams = [id, tenant_id, id, id, id, id, id, id];

    dbutil.sqlinjection(sqldb.MySQLConPool, CHECK_QRY, checkParams, 'deletesubcategory-check', function (err, rows) {
        if (err) return res.json({ status: 500, message: 'Internal server error' });

        var r = rows[0];
        if (!r.found) return res.json({ status: 202, message: 'Subcategory not found' });

        var usage = [];
        if (r.child_categories) usage.push(r.child_categories + ' child categories');
        if (r.products) usage.push(r.products + ' products');
        if (r.coupons) usage.push(r.coupons + ' coupons');
        if (r.vendors) usage.push(r.vendors + ' vendors');
        if (r.catalog_filters) usage.push(r.catalog_filters + ' catalog filters');
        if (r.category_attributes) usage.push(r.category_attributes + ' category attributes');

        if (usage.length) {
            return res.json({ status: 202, message: 'Cannot delete: this subcategory is currently used by ' + usage.join(', ') });
        }

        // Physical delete; parent_id IS NOT NULL guarantees a main category can never be deleted here
        var QRY = 'DELETE FROM categories WHERE id = ? AND tenant_id = ? AND parent_id IS NOT NULL';
        dbutil.sqlinjection(sqldb.MySQLConPool, QRY, [id, tenant_id], 'deletesubcategory', function (err2, result) {
            if (err2) return res.json({ status: 500, message: 'Internal server error' });
            if (!result || !result.affectedRows) return res.json({ status: 202, message: 'Subcategory not found' });
            return res.json({ status: 200, message: 'Subcategory deleted successfully' });
        });
    });
};

// =============================================
// VENDORS
// =============================================

// POST /addvendor
// POST /addvendor

// ---------------------------------------------------------------------------
// Shop Details - Payment Details are stored one row per shop in
// vendor_charge_settings. UNIQUE(vendor_id) makes this a single upsert, the
// same pattern tenant_website_footer_settings uses. Called by addvendor and
// updatevendor so Add and Edit share one code path.
// The tenant is enforced by the caller, which has already matched the vendor
// on tenant_id before reaching here.
// ---------------------------------------------------------------------------
// function saveVendorChargeSettings(vendorId, b, callback) {
//     if (!vendorId) return callback();

//     var QRY = "INSERT INTO vendor_charge_settings (" +
//         "vendor_id, admin_service, packing_charges, max_free_delivery_cost, " +
//         "minimum_order_amount, minimum_km, minimum_delivery_charge, " +
//         "per_km_charges, maximum_delivery_km" +
//         ") VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?) " +
//         "ON DUPLICATE KEY UPDATE " +
//         "admin_service = VALUES(admin_service), " +
//         "packing_charges = VALUES(packing_charges), " +
//         "max_free_delivery_cost = VALUES(max_free_delivery_cost), " +
//         "minimum_order_amount = VALUES(minimum_order_amount), " +
//         "minimum_km = VALUES(minimum_km), " +
//         "minimum_delivery_charge = VALUES(minimum_delivery_charge), " +
//         "per_km_charges = VALUES(per_km_charges), " +
//         "maximum_delivery_km = VALUES(maximum_delivery_km), " +
//         "d_in = 0";

//     var params = [
//         vendorId,
//         num(b.admin_service, 0),
//         num(b.packing_charges, 0),
//         num(b.max_free_delivery_cost, 0),
//         num(b.minimum_order_amount, 0),
//         num(b.minimum_km, 0),
//         num(b.minimum_delivery_charge, 0),
//         num(b.per_km_charges, 0),
//         num(b.maximum_delivery_km, 0)
//     ];

//     dbutil.sqlinjection(sqldb.MySQLConPool, QRY, params, 'saveVendorChargeSettings', function (err) {
//         if (err) {
//             console.log('SAVE VENDOR CHARGE SETTINGS ERROR:', err);
//         }
//         return callback(err);
//     });
// }
exports.addvendor = function (req, res) {
    var b = req.body;
    var tenant_id = req.admin.tenant_id;

    if (!b.vendor_name || !b.vendor_mobile_number) {
        return res.json({
            status: 202,
            message: 'Vendor name and mobile number are required'
        });
    }

    // Check duplicate mobile within tenant
    var checkQry =
        'SELECT id FROM vendors WHERE vendor_mobile_number = ? AND tenant_id = ? AND IFNULL(d_in,0) = 0';

    dbutil.sqlinjection(
        sqldb.MySQLConPool,
        checkQry,
        [b.vendor_mobile_number, tenant_id],
        'addvendor-check',
        function (err, rows) {

            if (err) {
                return res.json({
                    status: 500,
                    message: 'Internal server error'
                });
            }

            if (rows && rows.length > 0) {
                return res.json({
                    status: 300,
                    message: 'Vendor mobile number already exists'
                });
            }

            var QRY =
                "INSERT INTO vendors (" +
                "tenant_id, location_id, category_id, subcategory, filter, " +
                "vendor_name, vendor_unique_code, " +
                "vendor_mobile_number, vendor_mobile_number2, vendor_email, pwd, vendor_address, " +
                "latitude, longitude, fssai_license_number, gst_number, trade_license_number, " +
                "drug_license_number, pan_number, shop_image, shop_interior_image1, " +
                "shop_interior_image2, shop_interior_image3, bank_details_image, agreement_copy, " +
                "bank_account_holder, bank_account_number, " +
                "bank_ifsc_code, bank_name, upi_id, " +
                "opening_time, closing_time, opening_time2, closing_time2, weekly_holiday, " +
                "commission_percentage, kyc_status, is_online, login_status, active_status, i_ts" +
                ") VALUES (" +
                "?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, " +
                "?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, 0, 1, NOW()" +
                ")";

            var params = [
                tenant_id,
                nullableNum(b.location_id),
                nullableNum(b.category_id),
                emptyToNull(b.subcategory),
                emptyToNull(b.filter),

                b.vendor_name,
                b.vendor_unique_code || null,

                b.vendor_mobile_number,
                b.vendor_mobile_number2 || null,
                b.vendor_email || '',
                b.pwd || '123456',
                b.vendor_address || '',

                emptyToNull(b.latitude),
                emptyToNull(b.longitude),
                b.fssai_license_number || null,
                b.gst_number || null,
                b.trade_license_number || null,
                b.drug_license_number || null,
                b.pan_number || null,

                emptyToNull(b.shop_image),
                emptyToNull(b.shop_interior_image1),
                emptyToNull(b.shop_interior_image2),
                emptyToNull(b.shop_interior_image3),
                emptyToNull(b.bank_details_image),
                emptyToNull(b.agreement_copy),

                b.bank_account_holder || null,
                b.bank_account_number || null,
                b.bank_ifsc_code || null,
                b.bank_name || null,
                b.upi_id || null,

                emptyToNull(b.opening_time),
                emptyToNull(b.closing_time),
                emptyToNull(b.opening_time2),
                emptyToNull(b.closing_time2),
                emptyToNull(b.weekly_holiday),

                num(b.commission_percentage, 0),
                num(b.kyc_status, 0)
            ];

            dbutil.sqlinjection(
                sqldb.MySQLConPool,
                QRY,
                params,
                'addvendor',
                function (err, result) {

                    if (err) {
                        console.log('ADD VENDOR ERROR:', err);

                        return res.json({
                            status: 500,
                            message: 'Internal server error'
                        });
                    }

                    return res.json({
                        status: 200,
                        message: 'Vendor added successfully',
                        insertId: result.insertId
                    });
                }
            );
        }
    );
};


// GET /getvendors
exports.getvendors = function (req, res) {
    var tenant_id = req.admin.tenant_id;

    var QRY =
        "SELECT v.*, l.city, l.area, c.category_name " +
        "FROM vendors v " +
        "LEFT JOIN locations l ON l.id = v.location_id " +
        "LEFT JOIN categories c ON c.id = v.category_id " +
        "WHERE v.tenant_id = ? AND IFNULL(v.d_in,0) = 0 " +
        "ORDER BY v.i_ts DESC";

    dbutil.sqlinjection(
        sqldb.MySQLConPool,
        QRY,
        [tenant_id],
        'getvendors',
        function (err, rows) {

            if (err) {
                console.log('GET VENDORS ERROR:', err);
                return res.json({
                    status: 500,
                    message: 'Internal server error'
                });
            }

            return res.json({
                status: 200,
                data: rows
            });
        }
    );
};


// POST /updatevendor
exports.updatevendor = function (req, res) {
    var b = req.body;
    var tenant_id = req.admin.tenant_id;

    if (!b.id) {
        return res.json({
            status: 202,
            message: 'Vendor ID is required'
        });
    }

    // Update vendor details directly in the vendors table.
    var QRY =
        "UPDATE vendors SET " +
        "location_id = ?, category_id = ?, subcategory = ?, filter = ?, " +
        "vendor_name = ?, vendor_unique_code = ?, " +
        "vendor_mobile_number = ?, vendor_mobile_number2 = ?, vendor_email = ?, " +
        "vendor_address = ?, latitude = ?, longitude = ?, " +
        "fssai_license_number = ?, gst_number = ?, trade_license_number = ?, " +
        "drug_license_number = ?, pan_number = ?, " +
        "shop_image = ?, shop_interior_image1 = ?, shop_interior_image2 = ?, " +
        "shop_interior_image3 = ?, bank_details_image = ?, " +
        "special_offer = COALESCE(?, special_offer), " +
        "agreement_copy = COALESCE(?, agreement_copy), " +
        "bank_account_holder = ?, bank_account_number = ?, bank_ifsc_code = ?, " +
        "bank_name = ?, upi_id = ?, " +
        "opening_time = ?, closing_time = ?, opening_time2 = ?, closing_time2 = ?, " +
        "weekly_holiday = ?, commission_percentage = ?, kyc_status = ? " +
        "WHERE id = ? AND tenant_id = ?";

    var params = [
        nullableNum(b.location_id),
        nullableNum(b.category_id),
        emptyToNull(b.subcategory),
        emptyToNull(b.filter),

        b.vendor_name || '',
        b.vendor_unique_code || null,

        b.vendor_mobile_number || '',
        b.vendor_mobile_number2 || null,
        b.vendor_email || '',

        b.vendor_address || '',
        emptyToNull(b.latitude),
        emptyToNull(b.longitude),

        b.fssai_license_number || null,
        b.gst_number || null,
        b.trade_license_number || null,

        b.drug_license_number || null,
        b.pan_number || null,

        emptyToNull(b.shop_image),
        emptyToNull(b.shop_interior_image1),
        emptyToNull(b.shop_interior_image2),
        emptyToNull(b.shop_interior_image3),
        emptyToNull(b.bank_details_image),

        emptyToNull(b.special_offer),
        emptyToNull(b.agreement_copy),

        b.bank_account_holder || null,
        b.bank_account_number || null,
        b.bank_ifsc_code || null,
        b.bank_name || null,
        b.upi_id || null,

        emptyToNull(b.opening_time),
        emptyToNull(b.closing_time),
        emptyToNull(b.opening_time2),
        emptyToNull(b.closing_time2),

        emptyToNull(b.weekly_holiday),
        num(b.commission_percentage, 0),
        num(b.kyc_status, 0),

        b.id,
        tenant_id
    ];

    dbutil.sqlinjection(
        sqldb.MySQLConPool,
        QRY,
        params,
        'updatevendor',
        function (err, result) {

            if (err) {
                console.log('UPDATE VENDOR ERROR:', err);

                return res.json({
                    status: 500,
                    message: 'Internal server error'
                });
            }

            if (!result || !result.affectedRows) {
                return res.json({
                    status: 202,
                    message: 'Vendor not found'
                });
            }

            return res.json({
                status: 200,
                message: 'Vendor updated successfully',
                affectedRows: result.affectedRows
            });
        }
    );
};


// POST /deletevendor
exports.deletevendor = function (req, res) {
    var tenant_id = req.admin.tenant_id;
    var id = req.body.id;

    if (!id) {
        return res.json({
            status: 202,
            message: 'Vendor ID is required'
        });
    }

    var QRY =
        'DELETE FROM vendors WHERE id = ? AND tenant_id = ?';

    dbutil.sqlinjection(
        sqldb.MySQLConPool,
        QRY,
        [id, tenant_id],
        'deletevendor',
        function (err) {

            if (err) {
                return res.json({
                    status: 500,
                    message: 'Internal server error'
                });
            }

            return res.json({
                status: 200,
                message: 'Vendor deleted successfully'
            });
        }
    );
};


// POST /updatevendoractivestatus
exports.updatevendoractivestatus = function (req, res) {
    var tenant_id = req.admin.tenant_id;

    var QRY =
        'UPDATE vendors SET active_status = ? WHERE id = ? AND tenant_id = ?';

    dbutil.sqlinjection(
        sqldb.MySQLConPool,
        QRY,
        [
            req.body.value,
            req.body.id,
            tenant_id
        ],
        'updatevendoractivestatus',
        function (err) {

            if (err) {
                return res.json({
                    status: 500,
                    message: 'Internal server error'
                });
            }

            return res.json({
                status: 200,
                message: 'Vendor active status updated'
            });
        }
    );
};


// POST /updatevendorloginstatus
exports.updatevendorloginstatus = function (req, res) {
    var tenant_id = req.admin.tenant_id;

    var QRY =
        'UPDATE vendors SET login_status = ? WHERE id = ? AND tenant_id = ?';

    dbutil.sqlinjection(
        sqldb.MySQLConPool,
        QRY,
        [
            req.body.value,
            req.body.id,
            tenant_id
        ],
        'updatevendorloginstatus',
        function (err) {

            if (err) {
                return res.json({
                    status: 500,
                    message: 'Internal server error'
                });
            }

            return res.json({
                status: 200,
                message: 'Vendor login status updated'
            });
        }
    );
};

// =============================================
// DEV SUPPORT
// =============================================
// GET /getdevsupport
exports.getdevsupport = function (req, res) {
    var QRY = "SELECT " +
        "t.id, " +
        "t.raised_by, " +
        "t.subject, " +
        "t.description, " +
        "t.application, " +
        "t.ticket_type, " +
        "t.dev_status, " +
        "t.admin_status, " +
        "t.remarks, " +
        "t.image, " +
        "t.i_ts, " +
        "u.name AS entry_by " +
        "FROM dev_support_tickets t " +
        "LEFT JOIN admin_users_t u ON u.id = t.raised_by " +
        "WHERE IFNULL(t.d_in,0) = 0 " +
        "ORDER BY t.i_ts DESC";

    dbutil.sqlinjection(
        sqldb.MySQLConPool,
        QRY,
        [],
        'getdevsupport',
        function (err, rows) {
            if (err) {
                console.error('getdevsupport error:', err);
                return res.json({
                    status: 500,
                    message: 'Internal server error'
                });
            }

            return res.json({
                status: 200,
                data: rows
            });
        }
    );
};


// POST /adddevsupport
exports.adddevsupport = function (req, res) {
    var b = req.body;

    var QRY = "INSERT INTO dev_support_tickets " +
        "(raised_by, subject, description, application, ticket_type, " +
        "dev_status, admin_status, remarks, image, priority, status, i_ts) " +
        "VALUES (?, ?, ?, ?, ?, 0, 0, NULL, ?, ?, 0, NOW())";

    var params = [
        b.entry_by || req.admin.id,
        b.issue_title || b.subject,
        b.issue_description || b.description,
        b.application || null,
        b.ticket_type || 1,
req.file ? req.file.filename : null,
        b.priority || 'medium'
    ];

    dbutil.sqlinjection(
        sqldb.MySQLConPool,
        QRY,
        params,
        'adddevsupport',
        function (err, result) {
            if (err) {
                console.error('adddevsupport error:', err);
                return res.json({
                    status: 500,
                    message: 'Internal server error'
                });
            }

            return res.json({
                status: 200,
                message: 'Ticket created successfully',
                insertId: result.insertId
            });
        }
    );
};

// POST /updatedevstatus
exports.updatedevstatus = function (req, res) {
    var QRY = 'UPDATE dev_support_tickets SET dev_status = ? WHERE id = ?';
    dbutil.sqlinjection(sqldb.MySQLConPool, QRY, [req.body.value, req.body.id], 'updatedevstatus', function (err) {
        if (err) return res.json({ status: 500, message: 'Internal server error' });
        return res.json({ status: 200, message: 'Dev status updated' });
    });
};

// POST /updateadminstatus
exports.updateadminstatus = function (req, res) {
    var QRY = 'UPDATE dev_support_tickets SET admin_status = ? WHERE id = ?';
    dbutil.sqlinjection(sqldb.MySQLConPool, QRY, [req.body.value, req.body.id], 'updateadminstatus', function (err) {
        if (err) return res.json({ status: 500, message: 'Internal server error' });
        return res.json({ status: 200, message: 'Admin status updated' });
    });
};

// POST /updatetickettype
exports.updatetickettype = function (req, res) {
    var QRY = 'UPDATE dev_support_tickets SET ticket_type = ? WHERE id = ?';
    dbutil.sqlinjection(sqldb.MySQLConPool, QRY, [req.body.value, req.body.id], 'updatetickettype', function (err) {
        if (err) return res.json({ status: 500, message: 'Internal server error' });
        return res.json({ status: 200, message: 'Ticket type updated' });
    });
};

// POST /updateticketremarks
exports.updateticketremarks = function (req, res) {
    var QRY = 'UPDATE dev_support_tickets SET remarks = ? WHERE id = ?';
    dbutil.sqlinjection(sqldb.MySQLConPool, QRY, [req.body.remarks, req.body.id], 'updateticketremarks', function (err) {
        if (err) return res.json({ status: 500, message: 'Internal server error' });
        return res.json({ status: 200, message: 'Remarks updated' });
    });
};

// =============================================
// TENANT SETTINGS
// =============================================
// GET /getwebsitebanners
exports.getwebsitebanners = function (req, res) {

    var tenant_id = req.admin.tenant_id;

    var qry =
        "SELECT id, tenant_id, location, banner_image " +
        "FROM tenant_website_banners " +
        "WHERE tenant_id = ? " +
        "AND IFNULL(d_in,0) = 0 " +
        "ORDER BY id DESC";

    dbutil.sqlinjection(
        sqldb.MySQLConPool,
        qry,
        [tenant_id],
        'getwebsitebanners',
        function (err, rows) {

            if (err) {
                console.log('Get website banners error:', err);

                return res.json({
                    status: 500,
                    message: 'Internal server error'
                });
            }

            return res.json({
                status: 200,
                data: rows || []
            });
        }
    );
};


// POST /savewebsitebanner
exports.savewebsitebanner = function (req, res) {

    var b = req.body;
    var tenant_id = req.admin.tenant_id;

    var qry =
        "INSERT INTO tenant_website_banners " +
        "(tenant_id, location, banner_image) " +
        "VALUES (?, ?, ?)";

    var params = [
        tenant_id,
        b.location || '',
        b.banner_image || ''
    ];

    dbutil.sqlinjection(
        sqldb.MySQLConPool,
        qry,
        params,
        'savewebsitebanner',
        function (err, result) {

            if (err) {
                console.log('Save website banner error:', err);

                return res.json({
                    status: 500,
                    message: 'Failed to save banner'
                });
            }

            return res.json({
                status: 200,
                message: 'Banner saved successfully',
                id: result && result.insertId
                    ? result.insertId
                    : null
            });
        }
    );
};


// PUT /updatewebsitebanner/:id
exports.updatewebsitebanner = function (req, res) {

    var b = req.body;
    var tenant_id = req.admin.tenant_id;
    var id = req.params.id;

    if (!id) {
        return res.json({
            status: 202,
            message: 'Banner ID is required'
        });
    }

    var QRY =
        "UPDATE tenant_website_banners SET " +
        "location = ?, " +
        "banner_image = ? " +
        "WHERE id = ? " +
        "AND tenant_id = ? " +
        "AND IFNULL(d_in, 0) = 0";

    var params = [
        b.location || '',
        b.banner_image || '',
        id,
        tenant_id
    ];

    dbutil.sqlinjection(
        sqldb.MySQLConPool,
        QRY,
        params,
        'updatewebsitebanner',
        function (err, result) {

            if (err) {
                console.log(
                    'UPDATE WEBSITE BANNER ERROR:',
                    err
                );

                return res.json({
                    status: 500,
                    message: 'Internal server error'
                });
            }

            if (!result || !result.affectedRows) {
                return res.json({
                    status: 202,
                    message: 'Banner not found'
                });
            }

            return res.json({
                status: 200,
                message: 'Banner updated successfully'
            });
        }
    );
};


// DELETE /deletewebsitebanner/:id
exports.deletewebsitebanner = function (req, res) {

    var id = req.params.id;

    if (!id) {
        return res.json({
            status: 202,
            message: 'Banner ID is required'
        });
    }

    dbutil.sqlinjection(
        sqldb.MySQLConPool,
        'DELETE FROM tenant_website_banners WHERE id = ? AND tenant_id = ?',
        [id, req.admin.tenant_id],
        'deletewebsitebanner',
        function (err, result) {

            if (err) {
                console.log('DELETEWEBSITEBANNER ERROR:', err);

                return res.json({
                    status: 500,
                    message: 'Internal server error'
                });
            }

            if (!result || !result.affectedRows) {
                return res.json({
                    status: 202,
                    message: 'Banner not found'
                });
            }

            return res.json({
                status: 200,
                message: 'Banner deleted successfully',
                affectedRows: result.affectedRows
            });
        }
    );
};
// GET /gettenantsettings
exports.gettenantsettings = function (req, res) {
    var tenant_id = req.admin.tenant_id;

var settingsQry =
    "SELECT ts.*, t.tenant_name, t.tenant_unique_code, t.business_address, " +
    "t.owner_name, t.owner_mobile_number, t.logo_image, t.favicon_image " +
    "FROM tenant_settings ts " +
    "INNER JOIN tenants t ON t.id = ts.tenant_id " +
    "WHERE ts.tenant_id = ? AND IFNULL(t.d_in,0) = 0";

    dbutil.sqlinjection(sqldb.MySQLConPool, settingsQry, [tenant_id], 'gettenantsettings-settings', function (err, settingsRows) {
        if (err) return res.json({ status: 500, message: 'Internal server error' });

var brandQry =
    "SELECT tb.*, " +
    "twbs.website_title, " +
    "twbs.tagline " +
    "FROM tenant_branding tb " +
    "LEFT JOIN tenant_website_brand_settings twbs " +
    "ON twbs.tenant_id = tb.tenant_id " +
    "AND IFNULL(twbs.d_in,0) = 0 " +
    "WHERE tb.tenant_id = ? " +
    "AND IFNULL(tb.d_in,0) = 0";
            dbutil.sqlinjection(sqldb.MySQLConPool, brandQry, [tenant_id], 'gettenantsettings-branding', function (err2, brandRows) {
            if (err2) return res.json({ status: 500, message: 'Internal server error' });

            return res.json({
                status: 200,
                data: {
                    settings: settingsRows && settingsRows.length > 0 ? settingsRows[0] : {},
                    branding: brandRows && brandRows.length > 0 ? brandRows[0] : {}
                }
            });
        });
    });
};

// POST /updatetenantsettings
// POST /updatetenantsettings
exports.updatetenantsettings = function (req, res) {

    var b = req.body;
    var tenant_id = req.admin.tenant_id;

    // Update tenant_settings
    if (b.settings) {

        var s = b.settings;

        var settingsQry =
            "UPDATE tenant_settings SET " +
            "currency_code = ?, " +
            "currency_symbol = ?, " +
            "timezone = ?, " +
            "primary_color = ?, " +
            "secondary_color = ?, " +
            "default_language = ?, " +
            "support_email = ?, " +
            "support_phone = ? " +
            "WHERE tenant_id = ?";

        var settingsParams = [
            s.currency_code || 'INR',
            s.currency_symbol || '',
            s.timezone || 'Asia/Kolkata',
            s.primary_color || '#01003c',
            s.secondary_color || '#6c757d',
            s.default_language || 'en',
            s.support_email || '',
            s.support_phone || '',
            tenant_id
        ];

        dbutil.sqlinjection(
            sqldb.MySQLConPool,
            settingsQry,
            settingsParams,
            'updatetenantsettings-settings',
            function (err) {

                if (err) {
                    console.log('Tenant settings update error:', err);
                }
            }
        );


        // Update tenant master data
      var tenantQry =
    "UPDATE tenants SET " +
    "tenant_name = ?, " +
    "tenant_unique_code = ?, " +
    "business_address = ? " +
    "WHERE id = ?";

var tenantParams = [
    s.tenant_name || '',
    s.tenant_unique_code || '',
    s.business_address || '',
    tenant_id
];

        dbutil.sqlinjection(
            sqldb.MySQLConPool,
            tenantQry,
            tenantParams,
            'updatetenantsettings-tenant',
            function (err) {

                if (err) {
                    console.log('Tenant master update error:', err);
                }
            }
        );
    }
if (b.branding) {
    var br = b.branding;

    var websiteBrandQry =
        "INSERT INTO tenant_website_brand_settings " +
        "(tenant_id, website_title, tagline) " +
        "VALUES (?, ?, ?) " +
        "ON DUPLICATE KEY UPDATE " +
        "website_title = VALUES(website_title), " +
        "tagline = VALUES(tagline)";

    var websiteBrandParams = [
        tenant_id,
        br.website_title || '',
        br.tagline || ''
    ];

    dbutil.sqlinjection(
        sqldb.MySQLConPool,
        websiteBrandQry,
        websiteBrandParams,
        'updatetenantsettings-website-brand',
        function (err) {
            if (err) {
                console.log('Website brand settings update error:', err);
            }
        }
    );
}

    // Update the business name on the tenant record itself
    if (b.settings && b.settings.tenant_name) {
        var nameQry = "UPDATE tenants SET tenant_name = ? WHERE id = ? AND IFNULL(d_in,0) = 0";
        dbutil.sqlinjection(sqldb.MySQLConPool, nameQry, [String(b.settings.tenant_name).trim().slice(0, 255), tenant_id], 'updatetenantsettings-name', function () { });
    }

    // Update tenant_branding
    if (b.branding) {

        var br = b.branding;
        var brandParams = [
            br.logo_light || null, br.logo_dark || null, br.logo_icon || null, br.login_bg_image || null, br.favicon || null,
            br.primary_color || '#01003c', br.secondary_color || '#6c757d', br.sidebar_color || '#01003c',
            br.header_color || null, br.button_color || null,
            br.font_family || null, br.custom_css || null
        ];

        // Super Admin seeds a branding row per tenant, but upsert so a tenant
        // created before that backfill can still save its branding.
        var existsQry = "SELECT MIN(id) AS id FROM tenant_branding WHERE tenant_id = ? AND IFNULL(d_in,0) = 0";
        dbutil.sqlinjection(sqldb.MySQLConPool, existsQry, [tenant_id], 'updatetenantsettings-brand-exists', function (bErr, bRows) {
            if (bErr) return;
            if (bRows && bRows[0] && bRows[0].id) {
                var brandQry = "UPDATE tenant_branding SET logo_light = ?, logo_dark = ?, logo_icon = ?, login_bg_image = ?, favicon = ?, " +
                    "primary_color = ?, secondary_color = ?, sidebar_color = ?, header_color = ?, button_color = ?, " +
                    "font_family = ?, custom_css = ? WHERE id = ?";
                dbutil.sqlinjection(sqldb.MySQLConPool, brandQry, brandParams.concat([bRows[0].id]), 'updatetenantsettings-branding', function () { });
            } else {
                var insQry = "INSERT INTO tenant_branding (tenant_id, brand_scope, logo_light, logo_dark, logo_icon, login_bg_image, favicon, " +
                    "primary_color, secondary_color, sidebar_color, header_color, button_color, font_family, custom_css, i_ts) " +
                    "VALUES (?, 'admin_dashboard', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())";
                dbutil.sqlinjection(sqldb.MySQLConPool, insQry, [tenant_id].concat(brandParams), 'updatetenantsettings-branding-ins', function () { });
            }
        });

        // Keep the copies Super Admin reads on its tenant list in step
        var mirrorQry = "UPDATE tenants SET logo_image = COALESCE(?, logo_image), favicon_image = COALESCE(?, favicon_image) WHERE id = ?";
        dbutil.sqlinjection(sqldb.MySQLConPool, mirrorQry, [br.logo_light || null, br.favicon || null, tenant_id], 'updatetenantsettings-mirror', function () { });
    }

    return res.json({
        status: 200,
        message: 'Settings updated successfully'
    });
};

// Products
exports.addproduct = function(req, res) {
    var b = req.body;
    var QRY = "INSERT INTO products (vendor_id, category_id, product_name, product_code, description, base_price, discount_price, stock_quantity, is_veg, is_returnable,  active_status, i_ts) VALUES (?,?,?,?,?,?,?,?,?,?,?,1,NOW())";
    var params = [b.vendor_id, b.category_id, b.product_name, b.product_code||null, b.description||null, b.base_price, b.discount_price||null, b.stock_quantity||0, b.is_veg||0, b.is_returnable||0];
    dbutil.sqlinjection(sqldb.MySQLConPool, QRY, params, 'addproduct', function(err, result) {
        if (err) return res.json({ status: 500, message: 'Internal server error' });
        return res.json({ status: 200, message: 'Product added', insertId: result.insertId });
    });
};

exports.getproducts = function(req, res) {
    var tenant_id = req.admin.tenant_id;
    var QRY = "SELECT p.*, c.category_name, v.vendor_name FROM products p LEFT JOIN categories c ON c.id=p.category_id LEFT JOIN vendors v ON v.id=p.vendor_id WHERE v.tenant_id=? AND p.d_in=0 ORDER BY p.i_ts DESC";
    dbutil.sqlinjection(sqldb.MySQLConPool, QRY, [tenant_id], 'getproducts', function(err, rows) {
        if (err) return res.json({ status: 500, message: 'Internal server error' });
        return res.json({ status: 200, data: rows });
    });
};

exports.updateproduct = function(req, res) {
    var b = req.body;
    var QRY = "UPDATE products SET category_id=?, product_name=?, product_code=?, description=?, base_price=?, discount_price=?, stock_quantity=?, is_veg=?, is_returnable=?,  WHERE id=?";
    var params = [b.category_id, b.product_name, b.product_code, b.description, b.base_price, b.discount_price, b.stock_quantity, b.is_veg||0, b.is_returnable||0, b.id];
    dbutil.sqlinjection(sqldb.MySQLConPool, QRY, params, 'updateproduct', function(err) {
        if (err) return res.json({ status: 500, message: 'Internal server error' });
        return res.json({ status: 200, message: 'Product updated' });
    });
};

exports.deleteproduct = function(req, res) {

    console.log('DELETE PRODUCT BODY:', req.body);

    var tenant_id = req.admin.tenant_id;
    var ids = Array.isArray(req.body.id) ? req.body.id : [req.body.id];

    if (!ids.length || !ids[0]) {
        return res.json({
            status: 400,
            message: 'Product ID is required'
        });
    }

    var placeholders = ids.map(function() {
        return '?';
    }).join(',');

    var qry = 'DELETE FROM products WHERE id IN (' + placeholders + ') ' +
        'AND vendor_id IN (SELECT id FROM vendors WHERE tenant_id = ?)';

    dbutil.sqlinjection(
        sqldb.MySQLConPool,
        qry,
        ids.concat([tenant_id]),
        'deleteproduct',
        function(err) {

            console.log('DELETE PRODUCT ERROR:', err);

            if (err) {
                return res.json({
                    status: 500,
                    message: 'Internal server error'
                });
            }

            return res.json({
                status: 200,
                message: 'Product deleted'
            });

        }
    );
};
exports.updateproductactivestatus = function(req, res) {
    dbutil.sqlinjection(sqldb.MySQLConPool, 'UPDATE products SET active_status=? WHERE id=?', [req.body.active_status, req.body.id], 'updateproductactivestatus', function(err) {
        if (err) return res.json({ status: 500, message: 'Internal server error' });
        return res.json({ status: 200, message: 'Status updated' });
    });
};

// Delivery Partners
exports.adddeliverypartner = function(req, res) {
    var b = req.body;
    var tenant_id = req.admin.tenant_id;

    var aadhar_image =
        req.files &&
        req.files.aadhar_image &&
        req.files.aadhar_image[0]
            ? req.files.aadhar_image[0].filename
            : null;

    var pan_image =
        req.files &&
        req.files.pan_image &&
        req.files.pan_image[0]
            ? req.files.pan_image[0].filename
            : null;

    var bank_details_image =
        req.files &&
        req.files.bank_details_image &&
        req.files.bank_details_image[0]
            ? req.files.bank_details_image[0].filename
            : null;

    var driving_license_image =
        req.files &&
        req.files.driving_license_image &&
        req.files.driving_license_image[0]
            ? req.files.driving_license_image[0].filename
            : null;

    var checkQry =
        'SELECT id FROM delivery_partners WHERE mobile_number=? AND tenant_id=? AND d_in=0';

    dbutil.sqlinjection(
        sqldb.MySQLConPool,
        checkQry,
        [b.mobile_number, tenant_id],
        'adddeliverypartner-check',
        function(err, rows) {

            if (err) {
                return res.json({
                    status: 500,
                    message: 'Internal server error'
                });
            }

            if (rows && rows.length) {
                return res.json({
                    status: 300,
                    message: 'Mobile number already exists'
                });
            }

            var QRY =
                "INSERT INTO delivery_partners (" +
                "tenant_id, " +
                "name, " +
                "mobile_number, " +
                "pwd, " +
                "address, " +
                "location_id, " +
                "cod_limit, " +
                "aadhar_number, " +
                "aadhar_image, " +
                "driving_license_number, " +
                "driving_license_image, " +
                "pan_number, " +
                "pan_image, " +
                "vehicle_type, " +
                "vehicle_number, " +
                "bank_account_number, " +
                "bank_ifsc_code, " +
                "bank_details_image, " +
                "active_status, " +
                "i_ts" +
                ") VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,1,NOW())";

            var params = [
                tenant_id,
                b.name,
                b.mobile_number,
                b.pwd,
                b.address || null,
                b.location_id || null,
                b.cod_limit || 0,
                b.aadhar_number || null,
                aadhar_image,
                b.driving_license_number || null,
                driving_license_image,
                b.pan_number || null,
                pan_image,
                b.vehicle_type || null,
                b.vehicle_number || null,
                b.bank_account_number || null,
                b.bank_ifsc_code || null,
                bank_details_image
            ];

            dbutil.sqlinjection(
                sqldb.MySQLConPool,
                QRY,
                params,
                'adddeliverypartner',
                function(err2, result) {

                    if (err2) {
                        console.log(
                            'ADD DELIVERY PARTNER ERROR:',
                            err2
                        );

                        return res.json({
                            status: 500,
                            message: 'Internal server error'
                        });
                    }

                    return res.json({
                        status: 200,
                        message: 'Delivery partner added'
                    });
                }
            );
        }
    );
};

exports.getdeliverypartners = function(req, res) {
    var QRY =
        "SELECT " +
        "dp.id, " +
        "dp.name, " +
        "dp.mobile_number, " +
        "dp.pwd, " +
        "dp.address, " +
        "dp.location_id, " +
        "l.city AS location_name, " +
        "dp.cod_limit, " +
        "dp.aadhar_number, " +
        "dp.aadhar_image, " +
        "dp.pan_number, " +
        "dp.pan_image, " +
        "dp.bank_account_number, " +
        "dp.bank_ifsc_code, " +
        "dp.bank_details_image, " +
        "dp.driving_license_number, " +
        "dp.driving_license_image, " +
        "dp.login_status, " +
        "dp.active_status " +
        "FROM delivery_partners dp " +
        "LEFT JOIN locations l ON l.id=dp.location_id " +
        "WHERE dp.tenant_id=? " +
        "AND dp.d_in=0 " +
        "ORDER BY dp.i_ts DESC";

    dbutil.sqlinjection(
        sqldb.MySQLConPool,
        QRY,
        [req.admin.tenant_id],
        'getdeliverypartners',
        function(err, rows) {
            if (err) {
                console.log('GET DELIVERY PARTNERS ERROR:', err);

                return res.json({
                    status: 500,
                    message: 'Internal server error'
                });
            }

            return res.json({
                status: 200,
                data: rows || []
            });
        }
    );
};
exports.updatedeliverypartner = function(req, res) {
    var b = req.body;
    var tenant_id = req.admin.tenant_id;

    var getQry =
        "SELECT " +
        "aadhar_image, " +
        "pan_image, " +
        "bank_details_image, " +
        "driving_license_image " +
        "FROM delivery_partners " +
        "WHERE id=? AND tenant_id=?";

    dbutil.sqlinjection(
        sqldb.MySQLConPool,
        getQry,
        [b.id, tenant_id],
        'updatedeliverypartner-get',
        function(err, rows) {

            if (err) {
                return res.json({
                    status: 500,
                    message: 'Internal server error'
                });
            }

            if (!rows || !rows.length) {
                return res.json({
                    status: 202,
                    message: 'Delivery partner not found'
                });
            }

            var existing = rows[0];

            var aadhar_image =
                req.files &&
                req.files.aadhar_image &&
                req.files.aadhar_image[0]
                    ? req.files.aadhar_image[0].filename
                    : existing.aadhar_image;

            var pan_image =
                req.files &&
                req.files.pan_image &&
                req.files.pan_image[0]
                    ? req.files.pan_image[0].filename
                    : existing.pan_image;

            var bank_details_image =
                req.files &&
                req.files.bank_details_image &&
                req.files.bank_details_image[0]
                    ? req.files.bank_details_image[0].filename
                    : existing.bank_details_image;

            var driving_license_image =
                req.files &&
                req.files.driving_license_image &&
                req.files.driving_license_image[0]
                    ? req.files.driving_license_image[0].filename
                    : existing.driving_license_image;

            var QRY =
                "UPDATE delivery_partners SET " +
                "name=?, " +
                "mobile_number=?, " +
                "address=?, " +
                "location_id=?, " +
                "cod_limit=?, " +
                "aadhar_number=?, " +
                "aadhar_image=?, " +
                "driving_license_number=?, " +
                "driving_license_image=?, " +
                "pan_number=?, " +
                "pan_image=?, " +
                "bank_account_number=?, " +
                "bank_ifsc_code=?, " +
                "bank_details_image=? " +
                "WHERE id=? AND tenant_id=?";

            var params = [
                b.name,
                b.mobile_number,
                b.address || null,
                b.location_id || null,
                b.cod_limit || 0,
                b.aadhar_number || null,
                aadhar_image,
                b.driving_license_number || null,
                driving_license_image,
                b.pan_number || null,
                pan_image,
                b.bank_account_number || null,
                b.bank_ifsc_code || null,
                bank_details_image,
                b.id,
                tenant_id
            ];

            dbutil.sqlinjection(
                sqldb.MySQLConPool,
                QRY,
                params,
                'updatedeliverypartner',
                function(err2) {

                    if (err2) {
                        console.log(
                            'UPDATE DELIVERY PARTNER ERROR:',
                            err2
                        );

                        return res.json({
                            status: 500,
                            message: 'Internal server error'
                        });
                    }

                    return res.json({
                        status: 200,
                        message: 'Delivery partner updated'
                    });
                }
            );
        }
    );
};
// Hard delete, refused while assignments or settlements still reference the partner.
exports.deletedeliverypartner = function (req, res) {
    var tenant_id = req.admin.tenant_id;
    var id = req.body.id;
    if (!id) return res.json({ status: 202, message: 'Delivery partner ID is required' });

    var CHECK_QRY = "SELECT " +
        "(SELECT COUNT(*) FROM delivery_partners WHERE id = ? AND tenant_id = ?) AS found, " +
        "(SELECT COUNT(*) FROM delivery_assignments WHERE delivery_partner_id = ? AND IFNULL(d_in,0) = 0) AS assignments, " +
        "(SELECT COUNT(*) FROM delivery_partner_settlements WHERE delivery_partner_id = ? AND IFNULL(d_in,0) = 0) AS settlements";

    dbutil.sqlinjection(sqldb.MySQLConPool, CHECK_QRY, [id, tenant_id, id, id], 'deletedeliverypartner-check', function (err, rows) {
        if (err) return res.json({ status: 500, message: 'Internal server error' });
        var r = rows && rows[0];
        if (!r || !r.found) return res.json({ status: 202, message: 'Delivery partner not found' });

        var usage = [];
        if (r.assignments) usage.push(r.assignments + ' delivery assignment(s)');
        if (r.settlements) usage.push(r.settlements + ' settlement(s)');
        if (usage.length) {
            return res.json({ status: 202, message: 'Cannot delete: this delivery partner has ' + usage.join(', ') });
        }

        dbutil.sqlinjection(sqldb.MySQLConPool, 'DELETE FROM delivery_partners WHERE id = ? AND tenant_id = ?', [id, tenant_id], 'deletedeliverypartner', function (err2, result) {
            if (err2) return res.json({ status: 500, message: 'Internal server error' });
            if (!result || !result.affectedRows) return res.json({ status: 202, message: 'Delivery partner not found' });
            return res.json({ status: 200, message: 'Delivery partner deleted successfully', affectedRows: result.affectedRows });
        });
    });
};

exports.updatedeliverypartneractivestatus = function(req, res) {
    dbutil.sqlinjection(sqldb.MySQLConPool, 'UPDATE delivery_partners SET active_status=? WHERE id=? AND tenant_id=?', [req.body.value != undefined ? req.body.value : req.body.active_status, req.body.id, req.admin.tenant_id], 'updatedeliverypartneractivestatus', function(err) {
        if (err) return res.json({ status: 500, message: 'Internal server error' });
        return res.json({ status: 200, message: 'Status updated' });
    });
};

exports.updatedeliverypartnerloginstatus = function(req, res) {
    dbutil.sqlinjection(sqldb.MySQLConPool, 'UPDATE delivery_partners SET login_status=? WHERE id=? AND tenant_id=?', [req.body.value != undefined ? req.body.value : req.body.login_status, req.body.id, req.admin.tenant_id], 'updatedeliverypartnerloginstatus', function(err) {
        if (err) return res.json({ status: 500, message: 'Internal server error' });
        return res.json({ status: 200, message: 'Status updated' });
    });
};

// Delivery Slots
exports.adddeliveryslot = function(req, res) {
    var b = req.body;
    var QRY = "INSERT INTO delivery_slots (vendor_id, slot_label, start_time, end_time, slot_type, max_orders, is_active, i_ts) VALUES (?,?,?,?,?,?,1,NOW())";
    dbutil.sqlinjection(sqldb.MySQLConPool, QRY, [b.vendor_id, b.slot_label, b.start_time, b.end_time, b.slot_type||'delivery', b.max_orders||null], 'adddeliveryslot', function(err, result) {
        if (err) return res.json({ status: 500, message: 'Internal server error' });
        return res.json({ status: 200, message: 'Slot added' });
    });
};

exports.getdeliveryslots = function(req, res) {
    var QRY = "SELECT ds.*, v.vendor_name FROM delivery_slots ds LEFT JOIN vendors v ON v.id=ds.vendor_id WHERE v.tenant_id=? AND ds.d_in=0 ORDER BY ds.i_ts DESC";
    dbutil.sqlinjection(sqldb.MySQLConPool, QRY, [req.admin.tenant_id], 'getdeliveryslots', function(err, rows) {
        if (err) return res.json({ status: 500, message: 'Internal server error' });
        return res.json({ status: 200, data: rows });
    });
};

exports.updatedeliveryslot = function (req, res) {
    var b = req.body;
    if (!b.id) return res.json({ status: 202, message: 'Slot ID is required' });

    // delivery_slots carries no tenant_id, so the tenant is enforced through the
    // owning vendor. Without this a crafted id could edit another tenant's slot.
    var QRY = "UPDATE delivery_slots SET vendor_id = ?, slot_label = ?, start_time = ?, " +
        "end_time = ?, slot_type = ?, max_orders = ? " +
        "WHERE id = ? AND vendor_id IN (SELECT id FROM vendors WHERE tenant_id = ?)";

    var params = [
        nullableNum(b.vendor_id),
        b.slot_label || '',
        emptyToNull(b.start_time),
        emptyToNull(b.end_time),
        emptyToNull(b.slot_type),
        num(b.max_orders, 0),
        b.id,
        req.admin.tenant_id
    ];

    dbutil.sqlinjection(sqldb.MySQLConPool, QRY, params, 'updatedeliveryslot', function (err, result) {
        if (err) {
            console.log('UPDATE DELIVERY SLOT ERROR:', err);
            return res.json({ status: 500, message: 'Internal server error' });
        }
        if (!result || !result.affectedRows) {
            return res.json({ status: 202, message: 'Slot not found' });
        }
        return res.json({ status: 200, message: 'Slot updated', affectedRows: result.affectedRows });
    });
};

// Hard delete, scoped through the owning vendor because delivery_slots has no
// tenant_id column of its own.
exports.deletedeliveryslot = function (req, res) {
    var id = req.body.id;
    if (!id) return res.json({ status: 202, message: 'Slot ID is required' });
    var QRY = "DELETE FROM delivery_slots " +
        "WHERE id = ? AND vendor_id IN (SELECT id FROM vendors WHERE tenant_id = ?)";
    dbutil.sqlinjection(sqldb.MySQLConPool, QRY, [id, req.admin.tenant_id], 'deletedeliveryslot', function (err, result) {
        if (err) {
            console.log('DELETE DELIVERY SLOT ERROR:', err);
            return res.json({ status: 500, message: 'Internal server error' });
        }
        if (!result || !result.affectedRows) {
            return res.json({ status: 202, message: 'Slot not found' });
        }
        return res.json({ status: 200, message: 'Slot deleted successfully', affectedRows: result.affectedRows });
    });
};

// Orders
exports.getorders = function(req, res) {

    var tenant_id = req.admin.tenant_id;
    var b = req.body;
console.log('GET ORDERS FILTERS:', b);
    var conditions = ['v.tenant_id=?', 'o.d_in=0'];
    var params = [tenant_id];

   if (b.from_date && b.to_date) {
    conditions.push('o.order_date_time >= ? AND o.order_date_time < DATE_ADD(?, INTERVAL 1 DAY)');
    params.push(b.from_date, b.to_date);
}

    if (b.vendor_id) {
        conditions.push('o.vendor_id=?');
        params.push(b.vendor_id);
    }
if (b.category_id) {
    conditions.push('v.category_id=?');
    params.push(b.category_id);
}

if (b.location_id) {
    conditions.push('v.location_id=?');
    params.push(b.location_id);
}
    if (b.order_status !== undefined && b.order_status !== '') {
        conditions.push('o.order_status=?');
        params.push(b.order_status);
    }

    var WHERE = conditions.join(' AND ');

    // Get total number of matching orders
    var COUNT_QRY =
        "SELECT COUNT(*) as total " +
        "FROM orders o " +
        "LEFT JOIN customers c ON c.id=o.customer_id " +
        "LEFT JOIN vendors v ON v.id=o.vendor_id " +
        "WHERE " + WHERE;

    dbutil.sqlinjection(
        sqldb.MySQLConPool,
        COUNT_QRY,
        params,
        'getorders-count',
        function(err, countRows) {

            if (err) {
                return res.json({
                    status: 500,
                    message: 'Internal server error'
                });
            }

            var QRY =
                "SELECT o.*, c.customer_name, " +
                "c.mobile_number as customer_mobile, " +
                "v.vendor_name " +
                "FROM orders o " +
                "LEFT JOIN customers c ON c.id=o.customer_id " +
                "LEFT JOIN vendors v ON v.id=o.vendor_id " +
                "WHERE " + WHERE +
                " ORDER BY o.order_date_time DESC";

            dbutil.sqlinjection(
                sqldb.MySQLConPool,
                QRY,
                params,
                'getorders',
                function(err, rows) {

                    if (err) {
                        return res.json({
                            status: 500,
                            message: 'Internal server error'
                        });
                    }

                    return res.json({
                        status: 200,
                        data: rows,
                        total: countRows[0].total
                    });
                }
            );
        }
    );
};

exports.getorderdetails = function(req, res) {
    var QRY = "SELECT o.*, c.customer_name, c.mobile_number as customer_mobile, v.vendor_name FROM orders o LEFT JOIN customers c ON c.id=o.customer_id LEFT JOIN vendors v ON v.id=o.vendor_id WHERE o.id=?";
    dbutil.sqlinjection(sqldb.MySQLConPool, QRY, [req.body.order_id], 'getorderdetails-order', function(err, rows) {
        if (err || !rows.length) return res.json({ status: 500, message: 'Order not found' });
        var order = rows[0];
        dbutil.sqlinjection(sqldb.MySQLConPool, 'SELECT * FROM order_items WHERE order_id=? AND d_in=0', [req.body.order_id], 'getorderdetails-items', function(err2, items) {
            order.items = items || [];
            return res.json({ status: 200, data: order });
        });
    });
};

exports.updateorderstatus = function(req, res) {
    var b = req.body;

    // Get current order information first.
    dbutil.sqlinjection(
        sqldb.MySQLConPool,
        'SELECT order_status, payment_type, grand_total FROM orders WHERE id=? AND d_in=0',
        [b.order_id],
        'updateorderstatus-get',
        function(err, rows) {

            if (err) {
                return res.json({
                    status: 500,
                    message: 'Internal server error'
                });
            }

            if (!rows || !rows.length) {
                return res.json({
                    status: 202,
                    message: 'Order not found'
                });
            }

            var oldStatus = rows[0].order_status;
            var paymentType = rows[0].payment_type;
            var grandTotal = Number(rows[0].grand_total || 0);

            // Update order status.
            dbutil.sqlinjection(
                sqldb.MySQLConPool,
                'UPDATE orders SET order_status=? WHERE id=? AND d_in=0',
                [b.new_status, b.order_id],
                'updateorderstatus-update',
                function(err2) {

                    if (err2) {
                        return res.json({
                            status: 500,
                            message: 'Internal server error'
                        });
                    }

                    // Insert order status history.
                    dbutil.sqlinjection(
                        sqldb.MySQLConPool,
                        'INSERT INTO order_status_history ' +
                        '(order_id, old_status, new_status, changed_by_type, changed_by_id, remarks, i_ts) ' +
                        'VALUES (?,?,?,?,?,?,NOW())',
                        [
                            b.order_id,
                            oldStatus,
                            b.new_status,
                            'admin',
                            req.admin.id,
                            b.remarks || null
                        ],
                        'updateorderstatus-history',
                        function() {

                            /*
                             * COD SETTLEMENT
                             *
                             * Create a settlement only when:
                             * 1. Order becomes Completed (status 4)
                             * 2. Order is COD
                             * 3. Order has an active delivery assignment
                             * 4. A settlement does not already exist
                             */

                            if (
                                Number(b.new_status) !== 4 ||
                                String(paymentType || '').toLowerCase() !== 'cod'
                            ) {
                                return res.json({
                                    status: 200,
                                    message: 'Order status updated'
                                });
                            }

                            // Find the delivery assignment for this order.
                            var assignmentQry =
                                'SELECT da.id AS assignment_id, ' +
                                'da.delivery_partner_id ' +
                                'FROM delivery_assignments da ' +
                                'WHERE da.order_id=? ' +
                                'AND IFNULL(da.d_in,0)=0 ' +
                                'ORDER BY da.id DESC LIMIT 1';

                            dbutil.sqlinjection(
                                sqldb.MySQLConPool,
                                assignmentQry,
                                [b.order_id],
                                'updateorderstatus-assignment',
                                function(err3, assignmentRows) {

                                    if (err3) {
                                        console.log(
                                            'GET DELIVERY ASSIGNMENT ERROR:',
                                            err3
                                        );

                                        return res.json({
                                            status: 500,
                                            message: 'Order status updated, but settlement could not be created'
                                        });
                                    }

                                    // No delivery partner assigned.
                                    if (
                                        !assignmentRows ||
                                        !assignmentRows.length
                                    ) {
                                        return res.json({
                                            status: 200,
                                            message: 'Order status updated'
                                        });
                                    }

                                    var assignmentId =
                                        assignmentRows[0].assignment_id;

                                    var deliveryPartnerId =
                                        assignmentRows[0].delivery_partner_id;

                                    // Check whether settlement already exists.
                                    var settlementCheckQry =
                                        'SELECT id ' +
                                        'FROM delivery_partner_settlements ' +
                                        'WHERE delivery_assignment_id=? ' +
                                        'AND IFNULL(d_in,0)=0 ' +
                                        'LIMIT 1';

                                    dbutil.sqlinjection(
                                        sqldb.MySQLConPool,
                                        settlementCheckQry,
                                        [assignmentId],
                                        'updateorderstatus-settlement-check',
                                        function(err4, settlementRows) {

                                            if (err4) {
                                                console.log(
                                                    'CHECK COD SETTLEMENT ERROR:',
                                                    err4
                                                );

                                                return res.json({
                                                    status: 500,
                                                    message: 'Order status updated, but settlement could not be created'
                                                });
                                            }

                                            // Already settled.
                                            if (
                                                settlementRows &&
                                                settlementRows.length
                                            ) {
                                                return res.json({
                                                    status: 200,
                                                    message: 'Order status updated'
                                                });
                                            }

                                            /*
                                             * Get the latest delivery partner
                                             * earning configured for this tenant.
                                             */
                                            var chargeQry =
                                                'SELECT delivery_boy_order_amount ' +
                                                'FROM tenant_charge_settings ' +
                                                'WHERE tenant_id=? ' +
                                                'AND IFNULL(d_in,0)=0 ' +
                                                'ORDER BY i_ts DESC ' +
                                                'LIMIT 1';

                                            dbutil.sqlinjection(
                                                sqldb.MySQLConPool,
                                                chargeQry,
                                                [req.admin.tenant_id],
                                                'updateorderstatus-charge',
                                                function(err5, chargeRows) {

                                                    if (err5) {
                                                        console.log(
                                                            'GET DELIVERY CHARGE ERROR:',
                                                            err5
                                                        );

                                                        return res.json({
                                                            status: 500,
                                                            message: 'Order status updated, but settlement could not be created'
                                                        });
                                                    }

                                                    var deliveryEarnings = 0;

                                                    if (
                                                        chargeRows &&
                                                        chargeRows.length
                                                    ) {
                                                        deliveryEarnings =
                                                            Number(
                                                                chargeRows[0]
                                                                    .delivery_boy_order_amount || 0
                                                            );
                                                    }

                                                    /*
                                                     * Advance deduction is currently
                                                     * not implemented anywhere in
                                                     * the backend, so it is zero.
                                                     */
                                                    var advanceDeducted = 0;

                                                    var netPayable =
                                                        deliveryEarnings -
                                                        advanceDeducted;

                                                    /*
                                                     * Create COD settlement.
                                                     */
                                                    var settlementQry =
                                                        'INSERT INTO delivery_partner_settlements ' +
                                                        '(delivery_partner_id, ' +
                                                        'delivery_assignment_id, ' +
                                                        'settlement_period_start, ' +
                                                        'settlement_period_end, ' +
                                                        'total_orders, ' +
                                                        'cod_amount_collected, ' +
                                                        'delivery_earnings, ' +
                                                        'advance_deducted, ' +
                                                        'net_payable, ' +
                                                        'settlement_status, ' +
                                                        'i_ts, ' +
                                                        'd_in) ' +
                                                        'VALUES (?,?,?,?,?,?,?,?,?,0,NOW(),0)';

                                                    var settlementParams = [
                                                        deliveryPartnerId,
                                                        assignmentId,
                                                        new Date()
                                                            .toISOString()
                                                            .slice(0, 10),
                                                        new Date()
                                                            .toISOString()
                                                            .slice(0, 10),
                                                        1,
                                                        grandTotal,
                                                        deliveryEarnings,
                                                        advanceDeducted,
                                                        netPayable
                                                    ];

                                                    dbutil.sqlinjection(
                                                        sqldb.MySQLConPool,
                                                        settlementQry,
                                                        settlementParams,
                                                        'updateorderstatus-create-settlement',
                                                        function(err6) {

                                                            if (err6) {
                                                                console.log(
                                                                    'CREATE COD SETTLEMENT ERROR:',
                                                                    err6
                                                                );

                                                                return res.json({
                                                                    status: 500,
                                                                    message: 'Order status updated, but settlement could not be created'
                                                                });
                                                            }

                                                            return res.json({
                                                                status: 200,
                                                                message: 'Order completed and COD settlement created'
                                                            });
                                                        }
                                                    );
                                                }
                                            );
                                        }
                                    );
                                }
                            );
                        }
                    );
                }
            );
        }
    );
};
// GET /getcategory
exports.getcategory = function (req, res) {
    var tenant_id = req.admin.tenant_id;

    var QRY = "SELECT * FROM categories " +
        "WHERE tenant_id = ? " +
        "AND parent_id IS NULL " +
        "AND IFNULL(d_in,0) = 0 " +
        "ORDER BY category_order, i_ts DESC";

    dbutil.sqlinjection(
        sqldb.MySQLConPool,
        QRY,
        [tenant_id],
        'getcategory',
        function (err, rows) {
            if (err) {
                console.log('GET CATEGORY ERROR:', err);
                return res.json({
                    status: 500,
                    message: 'Internal server error'
                });
            }

            return res.json({
                status: 200,
                data: rows
            });
        }
    );
};
// GET /getmainfilter
exports.getmainfilter = function (req, res) {
    var tenant_id = req.admin.tenant_id;

    var QRY = "SELECT " +
        "cf.id, " +
        "cf.category_id, " +
        "cf.filter_name, " +
        "c.category_name " +
        "FROM catalog_filters cf " +
        "INNER JOIN categories c ON c.id = cf.category_id " +
        "WHERE c.tenant_id = ? " +
        "AND c.parent_id IS NULL " +
        "AND IFNULL(cf.d_in, 0) = 0 " +
        "ORDER BY cf.i_ts DESC";

    dbutil.sqlinjection(
        sqldb.MySQLConPool,
        QRY,
        [tenant_id],
        'getmainfilter',
        function (err, rows) {
            if (err) {
                console.log('GET MAIN FILTER ERROR:', err);
                return res.json({
                    status: 500,
                    message: 'Internal server error'
                });
            }

            return res.json({
                status: 200,
                data: rows
            });
        }
    );
};
// POST /addmainfilter
exports.addmainfilter = function (req, res) {
    var tenant_id = req.admin.tenant_id;
    var category_id = req.body.category_id;
    var filter_name = req.body.filter_name;

    if (!category_id || !filter_name) {
        return res.json({
            status: 202,
            message: 'Category and Main Filter are required'
        });
    }

    // Make sure the selected category belongs to the logged-in tenant
    // and is a main category.
    var CHECK_QRY = "SELECT id FROM categories " +
        "WHERE id = ? " +
        "AND tenant_id = ? " +
        "AND parent_id IS NULL " +
        "AND IFNULL(d_in, 0) = 0";

    dbutil.sqlinjection(
        sqldb.MySQLConPool,
        CHECK_QRY,
        [category_id, tenant_id],
        'addmainfilter-check-category',
        function (err, rows) {
            if (err) {
                console.log('ADD MAIN FILTER CATEGORY CHECK ERROR:', err);
                return res.json({
                    status: 500,
                    message: 'Internal server error'
                });
            }

            if (!rows || rows.length === 0) {
                return res.json({
                    status: 202,
                    message: 'Invalid category'
                });
            }

            var QRY = "INSERT INTO catalog_filters " +
                "(category_id, filter_name, i_ts, d_in) " +
                "VALUES (?, ?, NOW(), 0)";

            dbutil.sqlinjection(
                sqldb.MySQLConPool,
                QRY,
                [category_id, filter_name.trim()],
                'addmainfilter',
                function (err2, result) {
                    if (err2) {
                        console.log('ADD MAIN FILTER ERROR:', err2);
                        return res.json({
                            status: 500,
                            message: 'Internal server error'
                        });
                    }

                    return res.json({
                        status: 200,
                        message: 'Main filter added successfully',
                        id: result.insertId
                    });
                }
            );
        }
    );
};
// POST /updatemainfilter
exports.updatemainfilter = function (req, res) {
    var tenant_id = req.admin.tenant_id;
    var id = req.body.id;
    var category_id = req.body.category_id;
    var filter_name = req.body.filter_name;

    if (!id || !category_id || !filter_name) {
        return res.json({
            status: 202,
            message: 'ID, Category and Main Filter are required'
        });
    }

    // Make sure the selected category belongs to the logged-in tenant
    // and is a main category.
    var CHECK_QRY = "SELECT id FROM categories " +
        "WHERE id = ? " +
        "AND tenant_id = ? " +
        "AND parent_id IS NULL " +
        "AND IFNULL(d_in, 0) = 0";

    dbutil.sqlinjection(
        sqldb.MySQLConPool,
        CHECK_QRY,
        [category_id, tenant_id],
        'updatemainfilter-check-category',
        function (err, rows) {
            if (err) {
                console.log('UPDATE MAIN FILTER CATEGORY CHECK ERROR:', err);
                return res.json({
                    status: 500,
                    message: 'Internal server error'
                });
            }

            if (!rows || rows.length === 0) {
                return res.json({
                    status: 202,
                    message: 'Invalid category'
                });
            }

            // Make sure the Main Filter belongs to this tenant's category
            var FILTER_QRY = "SELECT cf.id FROM catalog_filters cf " +
                "INNER JOIN categories c ON c.id = cf.category_id " +
                "WHERE cf.id = ? " +
                "AND c.tenant_id = ? " +
                "AND IFNULL(cf.d_in, 0) = 0";

            dbutil.sqlinjection(
                sqldb.MySQLConPool,
                FILTER_QRY,
                [id, tenant_id],
                'updatemainfilter-check-filter',
                function (err2, filterRows) {
                    if (err2) {
                        console.log('UPDATE MAIN FILTER CHECK ERROR:', err2);
                        return res.json({
                            status: 500,
                            message: 'Internal server error'
                        });
                    }

                    if (!filterRows || filterRows.length === 0) {
                        return res.json({
                            status: 202,
                            message: 'Main filter not found'
                        });
                    }

                    var QRY = "UPDATE catalog_filters " +
                        "SET category_id = ?, filter_name = ? " +
                        "WHERE id = ? " +
                        "AND IFNULL(d_in, 0) = 0";

                    dbutil.sqlinjection(
                        sqldb.MySQLConPool,
                        QRY,
                        [category_id, filter_name.trim(), id],
                        'updatemainfilter',
                        function (err3, result) {
                            if (err3) {
                                console.log('UPDATE MAIN FILTER ERROR:', err3);
                                return res.json({
                                    status: 500,
                                    message: 'Internal server error'
                                });
                            }

                            if (!result || !result.affectedRows) {
                                return res.json({
                                    status: 202,
                                    message: 'Main filter not found'
                                });
                            }

                            return res.json({
                                status: 200,
                                message: 'Main filter updated successfully'
                            });
                        }
                    );
                }
            );
        }
    );
};
// DELETE /deletemainfilter/:id
exports.deletemainfilter = function (req, res) {
    var tenant_id = req.admin.tenant_id;
    var id = req.params.id;

    if (!id) {
        return res.json({
            status: 202,
            message: 'Main filter ID is required'
        });
    }

    // Make sure the Main Filter belongs to the logged-in tenant
    var CHECK_QRY = "SELECT cf.id FROM catalog_filters cf " +
        "INNER JOIN categories c ON c.id = cf.category_id " +
        "WHERE cf.id = ? " +
        "AND c.tenant_id = ? " +
        "AND IFNULL(cf.d_in, 0) = 0";

    dbutil.sqlinjection(
        sqldb.MySQLConPool,
        CHECK_QRY,
        [id, tenant_id],
        'deletemainfilter-check',
        function (err, rows) {
            if (err) {
                console.log('DELETE MAIN FILTER CHECK ERROR:', err);
                return res.json({
                    status: 500,
                    message: 'Internal server error'
                });
            }

            if (!rows || rows.length === 0) {
                return res.json({
                    status: 202,
                    message: 'Main filter not found'
                });
            }

            // Physical delete — the row is permanently removed
            var QRY = "DELETE FROM catalog_filters " +
                "WHERE id = ?";

            dbutil.sqlinjection(
                sqldb.MySQLConPool,
                QRY,
                [id],
                'deletemainfilter',
                function (err2, result) {
                    if (err2) {
                        console.log('DELETE MAIN FILTER ERROR:', err2);
                        return res.json({
                            status: 500,
                            message: 'Internal server error'
                        });
                    }

                    if (!result || !result.affectedRows) {
                        return res.json({
                            status: 202,
                            message: 'Main filter not found'
                        });
                    }

                    return res.json({
                        status: 200,
                        message: 'Main filter deleted successfully'
                    });
                }
            );
        }
    );
};
// Customers
exports.getcustomers = function(req, res) {

    var tenant_id = req.admin.tenant_id;

    var QRY = `
        SELECT
            c.*,

            COALESCE(
                (
                    SELECT ca.full_address
                    FROM customer_addresses ca
                    WHERE ca.customer_id = c.id
                      AND ca.d_in = 0
                      AND ca.is_default = 1
                    LIMIT 1
                ),
                (
                    SELECT ca.full_address
                    FROM customer_addresses ca
                    WHERE ca.customer_id = c.id
                      AND ca.d_in = 0
                    ORDER BY ca.id ASC
                    LIMIT 1
                )
            ) AS location,

            (
                SELECT COUNT(*)
                FROM orders o
                WHERE o.customer_id = c.id
                  AND o.d_in = 0
                  AND o.order_status = 4
            ) AS completed_orders,

            (
                SELECT COUNT(*)
                FROM orders o
                WHERE o.customer_id = c.id
                  AND o.d_in = 0
                  AND o.order_status IN (0, 1, 2, 3)
            ) AS pending_orders,

            (
                SELECT COUNT(*)
                FROM orders o
                WHERE o.customer_id = c.id
                  AND o.d_in = 0
                  AND o.order_status IN (5, 6)
            ) AS rejected_orders,

            (
                SELECT COUNT(*)
                FROM orders o
                WHERE o.customer_id = c.id
                  AND o.d_in = 0
            ) AS total_orders,

            (
                SELECT GROUP_CONCAT(DISTINCT v.location_id)
                FROM orders o
                INNER JOIN vendors v ON v.id = o.vendor_id
                WHERE o.customer_id = c.id
                  AND o.d_in = 0
            ) AS location_ids

        FROM customers c
        WHERE c.tenant_id = ?
          AND c.d_in = 0
        ORDER BY c.i_ts DESC
    `;

    dbutil.sqlinjection(
        sqldb.MySQLConPool,
        QRY,
        [tenant_id],
        'getcustomers',
        function(err, rows) {

          if (err) {
    console.log('getcustomers SQL ERROR:', err);
    return res.json({
        status: 500,
        message: 'Internal server error',
        error: err.message
    });
}

            return res.json({
                status: 200,
                data: rows
            });
        }
    );

};

exports.getcustomerdetails = function(req, res) {
    dbutil.sqlinjection(sqldb.MySQLConPool, 'SELECT * FROM customers WHERE id=? AND tenant_id=? AND d_in=0', [req.body.customer_id, req.admin.tenant_id], 'getcustomerdetails', function(err, rows) {
        if (err || !rows.length) return res.json({ status: 500, message: 'Customer not found' });
        var customer = rows[0];
        dbutil.sqlinjection(sqldb.MySQLConPool, 'SELECT * FROM customer_addresses WHERE customer_id=? AND d_in=0', [req.body.customer_id], 'getcustomerdetails-addr', function(err2, addrs) {
            customer.addresses = addrs || [];
            return res.json({ status: 200, data: customer });
        });
    });
};

exports.updatecustomeractivestatus = function(req, res) {
    dbutil.sqlinjection(sqldb.MySQLConPool, 'UPDATE customers SET active_status=? WHERE id=? AND tenant_id=?', [req.body.value != undefined ? req.body.value : req.body.active_status, req.body.id, req.admin.tenant_id], 'updatecustomeractivestatus', function(err) {
        if (err) return res.json({ status: 500, message: 'Internal server error' });
        return res.json({ status: 200, message: 'Status updated' });
    });
};

// Banners
exports.addbanner = function(req, res) {

    var b = req.body;
    var tenant_id = req.admin.tenant_id;

    var QRY = `
        INSERT INTO banners
        (
            tenant_id,
            location_id,
            banner_image,
            link_type,
            vendor_id,
            product_id,
            external_url,
            banner_order,
            is_active,
            i_ts
        )
        VALUES (?,?,?,?,?,?,?,?,?,NOW())
    `;

    var params = [
        tenant_id,
        b.location_id || null,
        b.banner_image || null,
        b.link_type || null,
        b.vendor_id || null,
        b.product_id || null,
        b.external_url || null,
        b.banner_order || 0,
        b.is_active != undefined ? b.is_active : 1
    ];

    dbutil.sqlinjection(
        sqldb.MySQLConPool,
        QRY,
        params,
        'addbanner',
        function(err) {

            if (err) {
                console.log('ADD BANNER ERROR:', err);

                return res.json({
                    status: 500,
                    message: 'Internal server error'
                });
            }

            return res.json({
                status: 200,
                message: 'Banner added'
            });

        }
    );

};

exports.getbanners = function(req, res) {

    var QRY = `
        SELECT
            b.*,
            v.vendor_name,
            CONCAT(IFNULL(l.city, ''), ' ', IFNULL(l.area, '')) AS location
        FROM banners b
        LEFT JOIN vendors v
            ON v.id = b.vendor_id
        LEFT JOIN locations l
            ON l.id = b.location_id
        WHERE b.tenant_id = ?
          AND b.d_in = 0
        ORDER BY b.banner_order
    `;

    dbutil.sqlinjection(
        sqldb.MySQLConPool,
        QRY,
        [req.admin.tenant_id],
        'getbanners',
        function(err, rows) {

            if (err) {
                console.log('GET BANNERS ERROR:', err);

                return res.json({
                    status: 500,
                    message: 'Internal server error'
                });
            }

            return res.json({
                status: 200,
                data: rows
            });

        }
    );

};

exports.updatebanner = function(req, res) {
    var b = req.body;
    var QRY = "UPDATE banners SET banner_image=COALESCE(?,banner_image), link_type=?, vendor_id=?, product_id=?, external_url=?, banner_order=?, is_active=? WHERE id=? AND tenant_id=?";
    dbutil.sqlinjection(sqldb.MySQLConPool, QRY, [b.banner_image||null, b.link_type, b.vendor_id||null, b.product_id||null, b.external_url||null, b.banner_order, b.is_active, b.id, req.admin.tenant_id], 'updatebanner', function(err) {
        if (err) return res.json({ status: 500, message: 'Internal server error' });
        return res.json({ status: 200, message: 'Banner updated' });
    });
};

// // Hard delete - the row is removed from banners, not flagged.
exports.deletebanner = function (req, res) {
    var id = req.body.id;
    if (!id) return res.json({ status: 202, message: 'Banner ID is required' });
    dbutil.sqlinjection(
        sqldb.MySQLConPool,
        'DELETE FROM banners WHERE id = ? AND tenant_id = ?',
        [id, req.admin.tenant_id],
        'deletebanner',
        function (err, result) {
            if (err) {
                console.log('DELETEBANNER ERROR:', err);
                return res.json({ status: 500, message: 'Internal server error' });
            }
            if (!result || !result.affectedRows) {
                return res.json({ status: 202, message: 'Banner not found' });
            }
            return res.json({
                status: 200,
                message: 'Banner deleted successfully',
                affectedRows: result.affectedRows
            });
        }
    );
};
// Coupons
// Coupons
// The coupons table carries two generations of columns. The dashboard UI and
// the coupons grid both use the newer set (coupon_code, discount_type,
// discount_value, min_order_value, valid_from, valid_upto, vendor_id,
// category_id), so that is what these endpoints read and write. The legacy
// columns (coupon_name, coupon_percentage, validate_from ...) are deliberately
// left untouched rather than dropped, so nothing that still reads them breaks.
exports.addcoupon = function(req, res) {
    var b = req.body;
    var tenant_id = req.admin.tenant_id;

    if (!b.coupon_name) {
        return res.json({ status: 202, message: 'Coupon name is required' });
    }

    var QRY = "INSERT INTO coupons (" +
        "tenant_id, location_id, shop_id, coupon_name, coupon_description, " +
        "coupon_percentage, coupon_upto_price, coupon_max_price_limit, " +
        "coupon_code, description, discount_type, discount_value, " +
        "is_active, i_ts" +
        ") VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'percentage', ?, 1, NOW())";

    var params = [
        tenant_id,
        nullableNum(b.location_id),
        nullableNum(b.shop_id),
        b.coupon_name,
        b.coupon_description || null,
        num(b.coupon_percentage, 0),
        nullableNum(b.coupon_upto_price),
        nullableNum(b.coupon_max_price_limit),

        // Required by the existing coupons table.
        b.coupon_name,
        b.coupon_description || null,
        num(b.coupon_percentage, 0)
    ];

    dbutil.sqlinjection(
        sqldb.MySQLConPool,
        QRY,
        params,
        'addcoupon',
        function(err, result) {
            if (err) {
                console.log('ADD COUPON ERROR:', err);
                return res.json({
                    status: 500,
                    message: 'Internal server error'
                });
            }

            return res.json({
                status: 200,
                message: 'Coupon added successfully',
                insertId: result ? result.insertId : null
            });
        }
    );
};


exports.getcoupons = function(req, res) {
    var QRY =
        "SELECT " +
        "co.id, " +
        "co.coupon_name, " +
        "co.coupon_description, " +
        "co.coupon_percentage, " +
        "co.coupon_upto_price, " +
        "co.coupon_max_price_limit, " +
        "co.location_id, " +
        "co.shop_id, " +
        "l.city AS location_name, " +
        "v.vendor_name AS shop_name " +
        "FROM coupons co " +
        "LEFT JOIN locations l ON l.id = co.location_id " +
        "LEFT JOIN vendors v ON v.id = co.shop_id " +
        "WHERE co.tenant_id = ? " +
        "AND IFNULL(co.d_in, 0) = 0 " +
        "ORDER BY co.i_ts DESC";

    dbutil.sqlinjection(
        sqldb.MySQLConPool,
        QRY,
        [req.admin.tenant_id],
        'getcoupons',
        function(err, rows) {
            if (err) {
                console.log('GET COUPONS ERROR:', err);
                return res.json({
                    status: 500,
                    message: 'Internal server error'
                });
            }

            return res.json({
                status: 200,
                data: rows
            });
        }
    );
};


exports.updatecoupon = function(req, res) {
    var b = req.body;
    var tenant_id = req.admin.tenant_id;

    if (!b.id) {
        return res.json({
            status: 202,
            message: 'Coupon ID is required'
        });
    }

    if (!b.coupon_name) {
        return res.json({
            status: 202,
            message: 'Coupon name is required'
        });
    }

    var QRY =
        "UPDATE coupons SET " +
        "location_id = ?, " +
        "shop_id = ?, " +
        "coupon_name = ?, " +
        "coupon_description = ?, " +
        "coupon_percentage = ?, " +
        "coupon_upto_price = ?, " +
        "coupon_max_price_limit = ?, " +

        // Keep the existing required/newer columns synchronized.
        "coupon_code = ?, " +
        "description = ?, " +
        "discount_type = 'percentage', " +
        "discount_value = ? " +

        "WHERE id = ? " +
        "AND tenant_id = ? " +
        "AND IFNULL(d_in, 0) = 0";

    var params = [
        nullableNum(b.location_id),
        nullableNum(b.shop_id),
        b.coupon_name,
        b.coupon_description || null,
        num(b.coupon_percentage, 0),
        nullableNum(b.coupon_upto_price),
        nullableNum(b.coupon_max_price_limit),

        b.coupon_name,
        b.coupon_description || null,
        num(b.coupon_percentage, 0),

        b.id,
        tenant_id
    ];

    dbutil.sqlinjection(
        sqldb.MySQLConPool,
        QRY,
        params,
        'updatecoupon',
        function(err, result) {
            if (err) {
                console.log('UPDATE COUPON ERROR:', err);
                return res.json({
                    status: 500,
                    message: 'Internal server error'
                });
            }

            if (!result || !result.affectedRows) {
                return res.json({
                    status: 202,
                    message: 'Coupon not found'
                });
            }

            return res.json({
                status: 200,
                message: 'Coupon updated successfully',
                affectedRows: result.affectedRows
            });
        }
    );
};


exports.deletecoupon = function(req, res) {
    var id = req.body.id;

    if (!id) {
        return res.json({
            status: 202,
            message: 'Coupon ID is required'
        });
    }

    dbutil.sqlinjection(
        sqldb.MySQLConPool,
        'DELETE FROM coupons WHERE id=? AND tenant_id=?',
        [id, req.admin.tenant_id],
        'deletecoupon',
        function(err, result) {
            if (err) {
                console.log('DELETE COUPON ERROR:', err);
                return res.json({
                    status: 500,
                    message: 'Internal server error'
                });
            }

            if (!result || !result.affectedRows) {
                return res.json({
                    status: 202,
                    message: 'Coupon not found'
                });
            }

            return res.json({
                status: 200,
                message: 'Coupon deleted successfully',
                affectedRows: result.affectedRows
            });
        }
    );
};

// Notifications
exports.addnotification = function(req, res) {
    var b = req.body; var tenant_id = req.admin.tenant_id;
    var QRY = "INSERT INTO notifications (tenant_id, title, message, target_type, notification_type, sent_at, i_ts) VALUES (?,?,?,?,?,NOW(),NOW())";
    dbutil.sqlinjection(sqldb.MySQLConPool, QRY, [tenant_id, b.title, b.message, b.target_type||'all', b.notification_type||'system'], 'addnotification', function(err) {
        if (err) return res.json({ status: 500, message: 'Internal server error' });
        return res.json({ status: 200, message: 'Notification sent' });
    });
};

exports.getnotifications = function(req, res) {
    dbutil.sqlinjection(sqldb.MySQLConPool, 'SELECT * FROM notifications WHERE tenant_id=? AND d_in=0 ORDER BY sent_at DESC', [req.admin.tenant_id], 'getnotifications', function(err, rows) {
        if (err) return res.json({ status: 500, message: 'Internal server error' });
        return res.json({ status: 200, data: rows });
    });
};

exports.deletenotification = function(req, res) {
    dbutil.sqlinjection(
        sqldb.MySQLConPool,
        'DELETE FROM notifications WHERE id=? AND tenant_id=?',
        [req.body.id, req.admin.tenant_id],
        'deletenotification',
        function(err) {

            if (err) {

                return res.json({
                    status: 500,
                    message: 'Internal server error'
                });
            }

            return res.json({
                status: 200,
                message: 'Deleted permanently'
            });

        }
    );

};
// Update Notification
exports.updatenotification = function(req, res) {

    var b = req.body;
    var tenant_id = req.admin.tenant_id;

    var QRY = `
        UPDATE notifications
        SET
            title = ?,
            message = ?
        WHERE id = ?
          AND tenant_id = ?
    `;

    dbutil.sqlinjection(
        sqldb.MySQLConPool,
        QRY,
        [
            b.title,
            b.message,
            b.id,
            tenant_id
        ],
        'updatenotification',
        function(err) {

            if (err) {
                console.log('UPDATE NOTIFICATION ERROR:', err);
                return res.json({
                    status: 500,
                    message: 'Internal server error'
                });
            }

            return res.json({
                status: 200,
                message: 'Notification updated'
            });
        }
    );
};
// Vendor Settlements
// GET /getcodsettlements - COD settlements for the tenant's delivery partners.
// delivery_partner_settlements carries no tenant_id of its own, so the tenant
// is reached through delivery_partners - the same shape getvendorsettlements
// uses for vendors. Read-only: no payout action is implied by existing code.
exports.getcodsettlements = function(req, res) {

    var QRY =
        "SELECT " +
        "dps.id, " +
        "dps.delivery_partner_id, " +
        "dps.delivery_assignment_id, " +
        "dps.settlement_period_start, " +
        "dps.settlement_period_end, " +
        "dps.total_orders, " +
        "dps.cod_amount_collected, " +
        "dps.delivery_earnings, " +
        "dps.advance_deducted, " +
        "dps.net_payable, " +
        "dps.settlement_status, " +
        "dps.paid_at, " +
        "dps.i_ts, " +
        "dp.name AS delivery_partner_name, " +
        "dp.mobile_number, " +
        "dp.profile_image, " +
        "o.order_date_time AS order_date " +

        "FROM delivery_partner_settlements dps " +

        "INNER JOIN delivery_partners dp " +
        "ON dp.id = dps.delivery_partner_id " +

        "LEFT JOIN delivery_assignments da " +
        "ON da.id = dps.delivery_assignment_id " +

        "LEFT JOIN orders o " +
        "ON o.id = da.order_id " +

        "WHERE dp.tenant_id = ? " +
        "AND IFNULL(dps.d_in,0) = 0 " +

        "ORDER BY dps.i_ts DESC";


    dbutil.sqlinjection(
        sqldb.MySQLConPool,
        QRY,
        [req.admin.tenant_id],
        'getcodsettlements',
        function(err, rows) {

            if (err) {

                console.log(
                    'GET COD SETTLEMENTS ERROR:',
                    err
                );

                return res.json({
                    status: 500,
                    message: 'Internal server error'
                });

            }

            rows = rows || [];

            var settlements = rows.filter(function(row) {

                return Number(row.settlement_status) === 0;

            });

            var history = rows.filter(function(row) {

                return (
                    row.paid_at !== null &&
                    row.paid_at !== undefined
                ) ||
                Number(row.settlement_status) === 1 ||
                Number(row.settlement_status) === 2;

            });

            return res.json({

                status: 200,

                settlements: settlements,

                history: history,

                data: rows

            });

        }
    );

};
exports.paycodsettlement = function(req, res) {

    var settlementId = req.body.settlement_id;

    if (!settlementId) {

        return res.json({
            status: 400,
            message: 'Settlement ID is required'
        });

    }

    var QRY =
        "UPDATE delivery_partner_settlements dps " +
        "INNER JOIN delivery_partners dp " +
        "ON dp.id = dps.delivery_partner_id " +
        "SET " +
        "dps.settlement_status = 1, " +
        "dps.paid_at = NOW() " +
        "WHERE dps.id = ? " +
        "AND dp.tenant_id = ? " +
        "AND IFNULL(dps.d_in,0) = 0 " +
        "AND IFNULL(dps.settlement_status,0) = 0";


    dbutil.sqlinjection(
        sqldb.MySQLConPool,
        QRY,
        [
            settlementId,
            req.admin.tenant_id
        ],
        'paycodsettlement',
        function(err, result) {

            if (err) {

                console.log(
                    'PAY COD SETTLEMENT ERROR:',
                    err
                );

                return res.json({
                    status: 500,
                    message: 'Internal server error'
                });

            }

            if (!result || result.affectedRows === 0) {

                return res.json({
                    status: 404,
                    message: 'Settlement not found or already settled'
                });

            }

            return res.json({
                status: 200,
                message: 'COD settlement paid successfully'
            });

        }
    );

};
exports.getvendorsettlements = function(req, res) {

    var tenant_id = req.admin.tenant_id;
    var b = req.body || {};

    var conditions = [
        'v.tenant_id=?',
        'vs.d_in=0'
    ];

    var params = [tenant_id];

    // From Date + To Date
    if (b.from_date && b.to_date) {
        conditions.push(
            'vs.period_start >= ? AND vs.period_end <= ?'
        );

        params.push(
            b.from_date,
            b.to_date
        );
    }

    // Location
    if (b.location_id) {
        conditions.push('v.location_id=?');
        params.push(b.location_id);
    }

    // Category
    if (b.category_id) {
        conditions.push('v.category_id=?');
        params.push(b.category_id);
    }

    // Shop
    if (b.vendor_id) {
        conditions.push('vs.vendor_id=?');
        params.push(b.vendor_id);
    }

    var WHERE = conditions.join(' AND ');

    var QRY =
        "SELECT " +
        "vs.*, " +
        "v.vendor_name, " +
        "v.shop_image, " +
        "v.location_id, " +
        "v.category_id " +
        "FROM vendor_settlements vs " +
        "LEFT JOIN vendors v ON v.id=vs.vendor_id " +
        "WHERE " + WHERE +
        " ORDER BY vs.i_ts DESC";

    dbutil.sqlinjection(
        sqldb.MySQLConPool,
        QRY,
        params,
        'getvendorsettlements',
        function(err, rows) {

            if (err) {

                console.log(
                    'GET VENDOR SETTLEMENTS ERROR:',
                    err
                );

                return res.json({
                    status: 500,
                    message: 'Internal server error'
                });
            }

            return res.json({
                status: 200,
                data: rows || []
            });
        }
    );
};

exports.createvendorsettlement = function(req, res) {
    var b = req.body;
    var num = 'SET-' + Date.now();
    var QRY = "INSERT INTO vendor_settlements (vendor_id, settlement_number, period_start, period_end, total_orders, gross_sales, commission_amount, net_payable, settlement_status, i_ts) VALUES (?,?,?,?,?,?,?,?,0,NOW())";
    dbutil.sqlinjection(sqldb.MySQLConPool, QRY, [b.vendor_id, num, b.period_start, b.period_end, b.total_orders||0, b.gross_sales||0, b.commission_amount||0, b.net_payable||0], 'createvendorsettlement', function(err) {
        if (err) return res.json({ status: 500, message: 'Internal server error' });
        return res.json({ status: 200, message: 'Settlement created' });
    });
};

exports.submitvendorpayout = function(req, res) {
    var b = req.body;
    var QRY = "INSERT INTO vendor_payouts (vendor_settlement_id, payout_amount, payout_method, transaction_reference, payout_proof, payout_status, paid_at, i_ts) VALUES (?,?,?,?,?,1,NOW(),NOW())";
    dbutil.sqlinjection(sqldb.MySQLConPool, QRY, [b.vendor_settlement_id, b.payout_amount, b.payout_method, b.transaction_reference||null, b.payout_proof||null], 'submitvendorpayout', function(err) {
        if (err) return res.json({ status: 500, message: 'Internal server error' });
        dbutil.sqlinjection(sqldb.MySQLConPool, 'UPDATE vendor_settlements SET settlement_status=2 WHERE id=?', [b.vendor_settlement_id], 'submitvendorpayout-update', function() {});
        return res.json({ status: 200, message: 'Payout submitted' });
    });
};

exports.getcharges = function(req, res) {

    var tenant_id = req.admin.tenant_id;

    var QRY = `
        SELECT *
        FROM tenant_charge_settings
        WHERE tenant_id = ?
        AND d_in = 0
        ORDER BY id DESC
    `;

    dbutil.sqlinjection(
        sqldb.MySQLConPool,
        QRY,
        [tenant_id],
        'getcharges',
        function(err, rows) {

            if (err) {

                console.log('GET CHARGES ERROR:', err);

                return res.json({
                    status: 500,
                    message: 'Internal server error'
                });
            }

            return res.json({
                status: 200,
                data: rows || []
            });

        }
    );
};


exports.addcharges = function(req, res) {

    var b = req.body;
    var tenant_id = req.admin.tenant_id;

    var QRY = `
        INSERT INTO tenant_charge_settings
        (
            tenant_id,
            support_number,
            mail_id,
            handling_charge,
            extra_charges,
            delivery_boy_order_amount,
            packing_charge,
            donation_charge,
            rain_surge_charge,
            rain_surge_active,
            i_ts,
            d_in
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), 0)
    `;

    dbutil.sqlinjection(
        sqldb.MySQLConPool,
        QRY,
        [
            tenant_id,
            b.support_number || null,
            b.mail_id || null,
            b.handling_charge || 0,
            b.extra_charges || 0,
            b.delivery_boy_order_amount || 0,
            b.packing_charge || 0,
            b.donation_charge || 0,
            b.rain_surge_charge || 0,
            b.rain_surge_active || 0
        ],
        'addcharges',
      function(err, result) {

    console.log('ADD CHARGES ERROR:', err);
    console.log('ADD CHARGES RESULT:', result);

    if (err) {
        return res.json({
            status: 500,
            message: 'Internal server error',
            error: err.message
        });
    }

    return res.json({
        status: 200,
        message: 'Charges added successfully',
        insertId: result.insertId
    });

}
    );
};


// The Settings page edits only a subset of the charge columns, so the fields it
// does not carry are written through COALESCE and keep whatever is stored. The
// standalone Charges page sends them all and still overwrites normally.
exports.updatecharges = function (req, res) {
    var b = req.body;
    var tenant_id = req.admin.tenant_id;

    if (!b.id) {
        return res.json({ status: 202, message: 'Charge ID is required' });
    }

    var QRY = "UPDATE tenant_charge_settings SET " +
        "support_number = COALESCE(?, support_number), " +
        "mail_id = COALESCE(?, mail_id), " +
        "handling_charge = ?, " +
        "extra_charges = COALESCE(?, extra_charges), " +
        "delivery_boy_order_amount = COALESCE(?, delivery_boy_order_amount), " +
        "packing_charge = ?, " +
        "donation_charge = ?, " +
        "rain_surge_charge = ?, " +
        "rain_surge_active = ? " +
        "WHERE id = ? AND tenant_id = ? AND IFNULL(d_in,0) = 0";

    var params = [
        emptyToNull(b.support_number),
        emptyToNull(b.mail_id),
        num(b.handling_charge, 0),
        nullableNum(b.extra_charges),
        nullableNum(b.delivery_boy_order_amount),
        num(b.packing_charge, 0),
        num(b.donation_charge, 0),
        num(b.rain_surge_charge, 0),
        num(b.rain_surge_active, 0),
        b.id,
        tenant_id
    ];

    dbutil.sqlinjection(sqldb.MySQLConPool, QRY, params, 'updatecharges', function (err, result) {
        if (err) {
            console.log('UPDATE CHARGES ERROR:', err);
            return res.json({ status: 500, message: 'Internal server error' });
        }
        if (!result || !result.affectedRows) {
            return res.json({ status: 202, message: 'Charges not found' });
        }
        return res.json({
            status: 200,
            message: 'Charges updated successfully',
            affectedRows: result.affectedRows
        });
    });
};

exports.getpaymentgateway = function(req, res) {
    dbutil.sqlinjection(sqldb.MySQLConPool, 'SELECT * FROM payment_gateway_settings WHERE tenant_id=? AND d_in=0', [req.admin.tenant_id], 'getpaymentgateway', function(err, rows) {
        if (err) return res.json({ status: 500, message: 'Internal server error' });
        return res.json({ status: 200, data: rows || [] });
    });
};

exports.updatepaymentgateway = function(req, res) {
    var b = req.body; var tenant_id = req.admin.tenant_id;
    var QRY = "INSERT INTO payment_gateway_settings (tenant_id, gateway_name, api_key, api_secret, webhook_secret, is_active, i_ts) VALUES (?,?,?,?,?,?,NOW()) ON DUPLICATE KEY UPDATE gateway_name=VALUES(gateway_name), api_key=VALUES(api_key), api_secret=VALUES(api_secret), webhook_secret=VALUES(webhook_secret), is_active=VALUES(is_active)";
    dbutil.sqlinjection(sqldb.MySQLConPool, QRY, [tenant_id, b.gateway_name, b.api_key||null, b.api_secret||null, b.webhook_secret||null, b.is_active!=undefined?b.is_active:1], 'updatepaymentgateway', function(err) {
        if (err) return res.json({ status: 500, message: 'Internal server error' });
        return res.json({ status: 200, message: 'Payment gateway updated' });
    });
};
// Add Shop Item
// Add Shop Item
exports.addshopitem = function(req, res) {

    var tenant_id = req.admin.tenant_id;
    var b = req.body;

    // Multer uploads the selected image and provides its file information here.
    var shopImage = req.file ? req.file.filename : null;

    var QRY = `
        INSERT INTO shopitems
        (
            tenant_id,
            subcategory,
            filter,
            item,
            description,
            measurement,
            actual_price,
            selling_price,
            available_time,
            discount_percentage,
            discount_amount,
            shop_image,
            i_ts,
            d_in
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), 0)
    `;

    var params = [
        tenant_id,
        b.subcategory || null,
        b.filter || null,
        b.item || null,
        b.description || null,
        b.measurement || null,
        b.actual_price || 0,
        b.selling_price || 0,
        b.available_time || null,
        b.discount_percentage || 0,
        b.discount_amount || 0,
        shopImage
    ];

    dbutil.sqlinjection(
        sqldb.MySQLConPool,
        QRY,
        params,
        'addshopitem',
        function(err, result) {

            if (err) {

                console.log('ADD SHOP ITEM ERROR:', err);

                return res.json({
                    status: 500,
                    message: 'Internal server error'
                });

            }

            return res.json({
                status: 200,
                message: 'Shop item added successfully',
                insertId: result.insertId
            });

        }
    );
};


// Shop Items
exports.getshopitems = function(req, res) {

    var tenant_id = req.admin.tenant_id;

    var QRY = `
        SELECT *
        FROM shopitems
        WHERE tenant_id = ?
          AND IFNULL(d_in, 0) = 0
        ORDER BY i_ts DESC
    `;

    dbutil.sqlinjection(
        sqldb.MySQLConPool,
        QRY,
        [tenant_id],
        'getshopitems',
        function(err, rows) {

            if (err) {
                console.log('GET SHOP ITEMS ERROR:', err);

                return res.json({
                    status: 500,
                    message: 'Internal server error'
                });
            }

            return res.json({
                status: 200,
                data: rows
            });
        }
    );
};


// Update Shop Item
exports.updateshopitem = function(req, res) {

    var tenant_id = req.admin.tenant_id;
    var b = req.body;

    // If a new image was selected, use the newly uploaded filename.
    // If no new image was selected while editing, keep the existing image.
    var shopImage = req.file
        ? req.file.filename
        : (b.existing_shop_image || null);

    var QRY = `
        UPDATE shopitems
        SET
            subcategory = ?,
            filter = ?,
            item = ?,
            description = ?,
            measurement = ?,
            actual_price = ?,
            selling_price = ?,
            available_time = ?,
            discount_percentage = ?,
            discount_amount = ?,
            shop_image = ?
        WHERE id = ?
          AND tenant_id = ?
    `;

    var params = [
        b.subcategory,
        b.filter,
        b.item,
        b.description,
        b.measurement,
        b.actual_price,
        b.selling_price,
        b.available_time,
        b.discount_percentage,
        b.discount_amount,
        shopImage,
        b.id,
        tenant_id
    ];

    dbutil.sqlinjection(
        sqldb.MySQLConPool,
        QRY,
        params,
        'updateshopitem',
        function(err, result) {

            if (err) {
                console.log('UPDATE SHOP ITEM ERROR:', err);

                return res.json({
                    status: 500,
                    message: 'Internal server error'
                });
            }

            return res.json({
                status: 200,
                message: 'Shop item updated successfully'
            });
        }
    );
};

exports.updateshopitemactivestatus = function(req, res) {

    var tenant_id = req.admin.tenant_id;

    var QRY = `
        UPDATE shopitems
        SET active_status = ?
        WHERE id = ?
          AND tenant_id = ?
    `;

    var params = [
        req.body.value,
        req.body.id,
        tenant_id
    ];

    dbutil.sqlinjection(
        sqldb.MySQLConPool,
        QRY,
        params,
        'updateshopitemactivestatus',
        function(err, result) {

            if (err) {
                console.log('UPDATE SHOP ITEM ACTIVE STATUS ERROR:', err);

                return res.json({
                    status: 500,
                    message: 'Internal server error'
                });
            }

            return res.json({
                status: 200,
                message: 'Shop item active status updated'
            });
        }
    );
};
// Delete Shop Item
exports.deleteshopitem = function(req, res) {

    var tenant_id = req.admin.tenant_id;
    var id = req.body.id;

    var QRY = `
        DELETE FROM shopitems
        WHERE id = ?
          AND tenant_id = ?
    `;

    dbutil.sqlinjection(
        sqldb.MySQLConPool,
        QRY,
        [id, tenant_id],
        'deleteshopitem',
        function(err, result) {

            if (err) {

                console.log(
                    'DELETE SHOP ITEM ERROR:',
                    err
                );

                return res.json({
                    status: 500,
                    message: 'Internal server error'
                });

            }

            return res.json({
                status: 200,
                message: 'Shop item deleted successfully'
            });

        }
    );
};
// ======================== PRODUCT ASSIGNMENT ========================
exports.getproductassignment = function(req, res) {

    var tenant_id = req.admin.tenant_id;

    var category_id = req.body.category_id;
    var shop_id = req.body.shop_id;

    if (!category_id || !shop_id) {
        return res.json({
            status: 400,
            message: 'Category and shop are required'
        });
    }

    var QRY = `
        SELECT
            p.id,
            p.product_name AS item,
            p.product_code,
            p.description,
            p.base_price AS actual_price,
            p.discount_price AS selling_price,
            p.stock_quantity,
            p.is_veg,
            p.is_returnable,
            p.is_available,
            p.active_status,
            p.category_id,
            p.vendor_id
        FROM products p
        INNER JOIN vendors v
            ON v.id = p.vendor_id
        WHERE p.vendor_id = ?
          AND p.category_id = ?
          AND v.tenant_id = ?
          AND p.d_in = 0
          AND p.active_status = 1
          AND p.is_available = 1
        ORDER BY p.i_ts DESC
    `;

    var params = [
        shop_id,
        category_id,
        tenant_id
    ];

    dbutil.sqlinjection(
        sqldb.MySQLConPool,
        QRY,
        params,
        'getproductassignment',
        function(err, rows) {

            if (err) {

                console.log(
                    'GET PRODUCT ASSIGNMENT ERROR:',
                    err
                );

                return res.json({
                    status: 500,
                    message: 'Internal server error'
                });
            }

            return res.json({
                status: 200,
                data: rows || []
            });

        }
    );
};
// ================= PRODUCT ASSIGNMENT =================

exports.submitproductassignment = function(req, res) {

    var tenant_id = req.admin.tenant_id;

    var category_id = req.body.category_id;
    var shop_id = req.body.shop_id;
    var phone_address = req.body.phone_address;
    var products = req.body.products;

    if (!category_id || !shop_id || !products || !Array.isArray(products) || products.length === 0) {

        return res.json({
            status: 400,
            message: 'Category, shop and products are required'
        });

    }

    var inserted = 0;

    function insertNext(index) {

        if (index >= products.length) {

            return res.json({
                status: 200,
                message: 'Products assigned successfully',
                inserted: inserted
            });

        }

        var QRY = `
            INSERT INTO product_assignments
            (
                tenant_id,
                category_id,
                shop_id,
                product_id,
                phone_address
            )
            VALUES (?, ?, ?, ?, ?)
        `;

        var params = [
            tenant_id,
            category_id,
            shop_id,
            products[index].id,
            phone_address || null
        ];

        dbutil.sqlinjection(
            sqldb.MySQLConPool,
            QRY,
            params,
            'submitproductassignment',
            function(err, result) {

                if (err) {

                    console.log(
                        'PRODUCT ASSIGNMENT ERROR:',
                        err
                    );

                    return res.json({
                        status: 500,
                        message: 'Internal server error'
                    });

                }

                inserted++;

                insertNext(index + 1);

            }
        );

    }

    insertNext(0);

};
exports.getpayments = function(req, res) {

    var tenant_id = req.admin.tenant_id;
    var b = req.body;

    console.log('GET PAYMENTS FILTERS:', b);
console.log('GET PAYMENTS SQL:', QRY);
console.log('GET PAYMENTS PARAMS:', params);
    var conditions = [
        'v.tenant_id=?',
        'o.d_in=0',
        'p.d_in=0'
    ];

    var params = [tenant_id];


    // Location filter
    if (b.location_id) {
        conditions.push('v.location_id=?');
        params.push(b.location_id);
    }


    // Category filter
  if (b.category_id) {
    conditions.push(`
        EXISTS (
            SELECT 1
            FROM order_items oi
            JOIN product_variants pv
                ON pv.id = oi.product_variant_id
            JOIN products p
                ON p.id = pv.product_id
            WHERE oi.order_id = o.id
              AND p.category_id = ?
        )
    `);
    params.push(b.category_id);
}

    // Date filter
    if (b.from_date && b.to_date) {

        conditions.push(
            'o.order_date_time >= ? AND o.order_date_time < DATE_ADD(?, INTERVAL 1 DAY)'
        );

        params.push(
            b.from_date,
            b.to_date
        );
    }


    var WHERE = conditions.join(' AND ');


    var QRY =
        "SELECT " +
        "v.id AS vendor_id, " +
        "v.vendor_name, " +
        "v.shop_image, " +
        "v.location_id, " +
        "v.category_id, " +
        "MIN(o.order_date_time) AS from_date, " +
        "MAX(o.order_date_time) AS to_date, " +
        "COUNT(DISTINCT o.id) AS total_orders, " +
        "COALESCE(SUM(p.amount), 0) AS total_amount " +

        "FROM payments p " +

        "LEFT JOIN orders o ON o.id=p.order_id " +

        "LEFT JOIN vendors v ON v.id=o.vendor_id " +

        "WHERE " + WHERE +

        " GROUP BY " +
        "v.id, " +
        "v.vendor_name, " +
        "v.shop_image, " +
        "v.location_id, " +
        "v.category_id " +

        "ORDER BY MAX(o.order_date_time) DESC";


    dbutil.sqlinjection(
        sqldb.MySQLConPool,
        QRY,
        params,
        'getpayments',
        function(err, rows) {

            if (err) {

                console.log('GET PAYMENTS ERROR:', err);

                return res.json({
                    status: 500,
                    message: 'Internal server error'
                });

            }


            return res.json({
                status: 200,
                data: rows || []
            });

        }
    );

};
exports.getcategoryimage = function (req, res) {
    var category_id = req.params.id;
var tenant_id = 1;
    var QRY = "SELECT category_image FROM categories " +
        "WHERE id = ? AND tenant_id = ? AND IFNULL(d_in, 0) = 0";

    dbutil.sqlinjection(
        sqldb.MySQLConPool,
        QRY,
        [category_id, tenant_id],
        'getcategoryimage',
        function (err, rows) {

            if (err) {
                console.log('GET CATEGORY IMAGE ERROR:', err);
                return res.status(500).send('Internal server error');
            }

            if (!rows || !rows.length || !rows[0].category_image) {
                return res.status(404).send('Image not found');
            }

            // Stored value is a data URL: "data:<mime>;base64,<data>"
            var match = /^data:(image\/[a-zA-Z0-9.+-]+);base64,(.+)$/.exec(rows[0].category_image);
            if (!match) {
                return res.status(404).send('Image not found');
            }

            var imageBuffer = Buffer.from(match[2], 'base64');

            res.setHeader('Content-Type', match[1]);
            res.setHeader('Content-Length', imageBuffer.length);

            res.end(imageBuffer);
        }
    );
};
// =============================================
// WEBSITE MANAGEMENT CONTENT
// Home sections, promotional sections, testimonials and footer settings.
// Same shape as the existing website banner endpoints: tenant_id comes from the
// token, d_in is a soft delete, display_order + status drive the public site.
// =============================================

// GET /getwebsitehomesections
exports.getwebsitehomesections = function (req, res) {
    var QRY = "SELECT id, tenant_id, section_key, heading, subheading, image, display_order, status " +
        "FROM tenant_website_home_sections " +
        "WHERE tenant_id = ? AND IFNULL(d_in,0) = 0 " +
        "ORDER BY display_order ASC, id DESC";
    dbutil.sqlinjection(sqldb.MySQLConPool, QRY, [req.admin.tenant_id], 'getwebsitehomesections', function (err, rows) {
        if (err) {
            console.log('GET WEBSITE HOME SECTIONS ERROR:', err);
            return res.json({ status: 500, message: 'Internal server error' });
        }
        return res.json({ status: 200, data: rows || [] });
    });
};

// POST /savewebsitehomesection
exports.savewebsitehomesection = function (req, res) {
    var b = req.body;
    if (!b.section_key) {
        return res.json({ status: 202, message: 'Section key is required' });
    }
    var QRY = "INSERT INTO tenant_website_home_sections " +
        "(tenant_id, section_key, heading, subheading, image, display_order, status) " +
        "VALUES (?, ?, ?, ?, ?, ?, ?)";
    var params = [
        req.admin.tenant_id,
        b.section_key,
        b.heading || '',
        b.subheading || '',
        b.image || '',
        b.display_order || 1,
        b.status !== undefined ? b.status : 1
    ];
    dbutil.sqlinjection(sqldb.MySQLConPool, QRY, params, 'savewebsitehomesection', function (err, result) {
        if (err) {
            console.log('SAVE WEBSITE HOME SECTION ERROR:', err);
            return res.json({ status: 500, message: 'Failed to save home section' });
        }
        return res.json({ status: 200, message: 'Home section saved successfully', insertId: result.insertId });
    });
};

// PUT /updatewebsitehomesection/:id
exports.updatewebsitehomesection = function (req, res) {
    var b = req.body;
    var id = req.params.id;
    if (!id) {
        return res.json({ status: 202, message: 'Home section ID is required' });
    }
    var QRY = "UPDATE tenant_website_home_sections SET " +
        "section_key = ?, heading = ?, subheading = ?, image = ?, display_order = ?, status = ? " +
        "WHERE id = ? AND tenant_id = ? AND IFNULL(d_in,0) = 0";
    var params = [
        b.section_key || '',
        b.heading || '',
        b.subheading || '',
        b.image || '',
        b.display_order || 1,
        b.status !== undefined ? b.status : 1,
        id,
        req.admin.tenant_id
    ];
    dbutil.sqlinjection(sqldb.MySQLConPool, QRY, params, 'updatewebsitehomesection', function (err) {
        if (err) {
            console.log('UPDATE WEBSITE HOME SECTION ERROR:', err);
            return res.json({ status: 500, message: 'Internal server error' });
        }
        return res.json({ status: 200, message: 'Home section updated successfully' });
    });
};

// DELETE /deletewebsitehomesection/:id
// Hard delete - the row is removed from tenant_website_home_sections, not flagged.
exports.deletewebsitehomesection = function (req, res) {
    var id = req.params.id;
    if (!id) return res.json({ status: 202, message: 'Home section ID is required' });
    dbutil.sqlinjection(
        sqldb.MySQLConPool,
        'DELETE FROM tenant_website_home_sections WHERE id = ? AND tenant_id = ?',
        [id, req.admin.tenant_id],
        'deletewebsitehomesection',
        function (err, result) {
            if (err) {
                console.log('DELETEWEBSITEHOMESECTION ERROR:', err);
                return res.json({ status: 500, message: 'Internal server error' });
            }
            if (!result || !result.affectedRows) {
                return res.json({ status: 202, message: 'Home section not found' });
            }
            return res.json({
                status: 200,
                message: 'Home section deleted successfully',
                affectedRows: result.affectedRows
            });
        }
    );
};

// GET /getwebsitepromosections
exports.getwebsitepromosections = function (req, res) {
    var QRY = "SELECT id, tenant_id, title, subtitle, image, link_url, display_order, status " +
        "FROM tenant_website_promo_sections " +
        "WHERE tenant_id = ? AND IFNULL(d_in,0) = 0 " +
        "ORDER BY display_order ASC, id DESC";
    dbutil.sqlinjection(sqldb.MySQLConPool, QRY, [req.admin.tenant_id], 'getwebsitepromosections', function (err, rows) {
        if (err) {
            console.log('GET WEBSITE PROMO SECTIONS ERROR:', err);
            return res.json({ status: 500, message: 'Internal server error' });
        }
        return res.json({ status: 200, data: rows || [] });
    });
};

// POST /savewebsitepromosection
exports.savewebsitepromosection = function (req, res) {
    var b = req.body;
    if (!b.title) {
        return res.json({ status: 202, message: 'Title is required' });
    }
    var QRY = "INSERT INTO tenant_website_promo_sections " +
        "(tenant_id, title, subtitle, image, link_url, display_order, status) " +
        "VALUES (?, ?, ?, ?, ?, ?, ?)";
    var params = [
        req.admin.tenant_id,
        b.title,
        b.subtitle || '',
        b.image || '',
        b.link_url || '',
        b.display_order || 1,
        b.status !== undefined ? b.status : 1
    ];
    dbutil.sqlinjection(sqldb.MySQLConPool, QRY, params, 'savewebsitepromosection', function (err, result) {
        if (err) {
            console.log('SAVE WEBSITE PROMO SECTION ERROR:', err);
            return res.json({ status: 500, message: 'Failed to save promotional section' });
        }
        return res.json({ status: 200, message: 'Promotional section saved successfully', insertId: result.insertId });
    });
};

// PUT /updatewebsitepromosection/:id
exports.updatewebsitepromosection = function (req, res) {
    var b = req.body;
    var id = req.params.id;
    if (!id) {
        return res.json({ status: 202, message: 'Promotional section ID is required' });
    }
    var QRY = "UPDATE tenant_website_promo_sections SET " +
        "title = ?, subtitle = ?, image = ?, link_url = ?, display_order = ?, status = ? " +
        "WHERE id = ? AND tenant_id = ? AND IFNULL(d_in,0) = 0";
    var params = [
        b.title || '',
        b.subtitle || '',
        b.image || '',
        b.link_url || '',
        b.display_order || 1,
        b.status !== undefined ? b.status : 1,
        id,
        req.admin.tenant_id
    ];
    dbutil.sqlinjection(sqldb.MySQLConPool, QRY, params, 'updatewebsitepromosection', function (err) {
        if (err) {
            console.log('UPDATE WEBSITE PROMO SECTION ERROR:', err);
            return res.json({ status: 500, message: 'Internal server error' });
        }
        return res.json({ status: 200, message: 'Promotional section updated successfully' });
    });
};

// DELETE /deletewebsitepromosection/:id
// Hard delete - the row is removed from tenant_website_promo_sections, not flagged.
exports.deletewebsitepromosection = function (req, res) {
    var id = req.params.id;
    if (!id) return res.json({ status: 202, message: 'Promotional section ID is required' });
    dbutil.sqlinjection(
        sqldb.MySQLConPool,
        'DELETE FROM tenant_website_promo_sections WHERE id = ? AND tenant_id = ?',
        [id, req.admin.tenant_id],
        'deletewebsitepromosection',
        function (err, result) {
            if (err) {
                console.log('DELETEWEBSITEPROMOSECTION ERROR:', err);
                return res.json({ status: 500, message: 'Internal server error' });
            }
            if (!result || !result.affectedRows) {
                return res.json({ status: 202, message: 'Promotional section not found' });
            }
            return res.json({
                status: 200,
                message: 'Promotional section deleted successfully',
                affectedRows: result.affectedRows
            });
        }
    );
};

// GET /getwebsitetestimonials
exports.getwebsitetestimonials = function (req, res) {
    var QRY = "SELECT id, tenant_id, customer_name, designation, photo, rating, message, display_order, status " +
        "FROM tenant_website_testimonials " +
        "WHERE tenant_id = ? AND IFNULL(d_in,0) = 0 " +
        "ORDER BY display_order ASC, id DESC";
    dbutil.sqlinjection(sqldb.MySQLConPool, QRY, [req.admin.tenant_id], 'getwebsitetestimonials', function (err, rows) {
        if (err) {
            console.log('GET WEBSITE TESTIMONIALS ERROR:', err);
            return res.json({ status: 500, message: 'Internal server error' });
        }
        return res.json({ status: 200, data: rows || [] });
    });
};

// POST /savewebsitetestimonial
exports.savewebsitetestimonial = function (req, res) {
    var b = req.body;
    if (!b.customer_name) {
        return res.json({ status: 202, message: 'Customer name is required' });
    }
    var QRY = "INSERT INTO tenant_website_testimonials " +
        "(tenant_id, customer_name, designation, photo, rating, message, display_order, status) " +
        "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
    var params = [
        req.admin.tenant_id,
        b.customer_name,
        b.designation || '',
        b.photo || '',
        b.rating !== undefined && b.rating !== null && b.rating !== '' ? b.rating : 5,
        b.message || '',
        b.display_order || 1,
        b.status !== undefined ? b.status : 1
    ];
    dbutil.sqlinjection(sqldb.MySQLConPool, QRY, params, 'savewebsitetestimonial', function (err, result) {
        if (err) {
            console.log('SAVE WEBSITE TESTIMONIAL ERROR:', err);
            return res.json({ status: 500, message: 'Failed to save testimonial' });
        }
        return res.json({ status: 200, message: 'Testimonial saved successfully', insertId: result.insertId });
    });
};

// PUT /updatewebsitetestimonial/:id
exports.updatewebsitetestimonial = function (req, res) {
    var b = req.body;
    var id = req.params.id;
    if (!id) {
        return res.json({ status: 202, message: 'Testimonial ID is required' });
    }
    var QRY = "UPDATE tenant_website_testimonials SET " +
        "customer_name = ?, designation = ?, photo = ?, rating = ?, message = ?, display_order = ?, status = ? " +
        "WHERE id = ? AND tenant_id = ? AND IFNULL(d_in,0) = 0";
    var params = [
        b.customer_name || '',
        b.designation || '',
        b.photo || '',
        b.rating !== undefined && b.rating !== null && b.rating !== '' ? b.rating : 5,
        b.message || '',
        b.display_order || 1,
        b.status !== undefined ? b.status : 1,
        id,
        req.admin.tenant_id
    ];
    dbutil.sqlinjection(sqldb.MySQLConPool, QRY, params, 'updatewebsitetestimonial', function (err) {
        if (err) {
            console.log('UPDATE WEBSITE TESTIMONIAL ERROR:', err);
            return res.json({ status: 500, message: 'Internal server error' });
        }
        return res.json({ status: 200, message: 'Testimonial updated successfully' });
    });
};

// DELETE /deletewebsitetestimonial/:id
// Hard delete - the row is removed from tenant_website_testimonials, not flagged.
exports.deletewebsitetestimonial = function (req, res) {
    var id = req.params.id;
    if (!id) return res.json({ status: 202, message: 'Testimonial ID is required' });
    dbutil.sqlinjection(
        sqldb.MySQLConPool,
        'DELETE FROM tenant_website_testimonials WHERE id = ? AND tenant_id = ?',
        [id, req.admin.tenant_id],
        'deletewebsitetestimonial',
        function (err, result) {
            if (err) {
                console.log('DELETEWEBSITETESTIMONIAL ERROR:', err);
                return res.json({ status: 500, message: 'Internal server error' });
            }
            if (!result || !result.affectedRows) {
                return res.json({ status: 202, message: 'Testimonial not found' });
            }
            return res.json({
                status: 200,
                message: 'Testimonial deleted successfully',
                affectedRows: result.affectedRows
            });
        }
    );
};

// GET /getwebsitefootersettings - one row per tenant
exports.getwebsitefootersettings = function (req, res) {
    var QRY = "SELECT * FROM tenant_website_footer_settings " +
        "WHERE tenant_id = ? AND IFNULL(d_in,0) = 0 LIMIT 1";
    dbutil.sqlinjection(sqldb.MySQLConPool, QRY, [req.admin.tenant_id], 'getwebsitefootersettings', function (err, rows) {
        if (err) {
            console.log('GET WEBSITE FOOTER SETTINGS ERROR:', err);
            return res.json({ status: 500, message: 'Internal server error' });
        }
        return res.json({ status: 200, data: (rows && rows[0]) || {} });
    });
};

// POST /updatewebsitefootersettings - upsert on the tenant's single row
exports.updatewebsitefootersettings = function (req, res) {
    var b = req.body;
    var QRY = "INSERT INTO tenant_website_footer_settings " +
        "(tenant_id, about_text, contact_email, contact_phone, contact_address, " +
        "facebook_url, instagram_url, twitter_url, youtube_url, linkedin_url, " +
        "playstore_url, appstore_url, copyright_text) " +
        "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) " +
        "ON DUPLICATE KEY UPDATE " +
        "about_text = VALUES(about_text), contact_email = VALUES(contact_email), " +
        "contact_phone = VALUES(contact_phone), contact_address = VALUES(contact_address), " +
        "facebook_url = VALUES(facebook_url), instagram_url = VALUES(instagram_url), " +
        "twitter_url = VALUES(twitter_url), youtube_url = VALUES(youtube_url), " +
        "linkedin_url = VALUES(linkedin_url), playstore_url = VALUES(playstore_url), " +
        "appstore_url = VALUES(appstore_url), copyright_text = VALUES(copyright_text), d_in = 0";
    var params = [
        req.admin.tenant_id,
        b.about_text || '',
        b.contact_email || '',
        b.contact_phone || '',
        b.contact_address || '',
        b.facebook_url || '',
        b.instagram_url || '',
        b.twitter_url || '',
        b.youtube_url || '',
        b.linkedin_url || '',
        b.playstore_url || '',
        b.appstore_url || '',
        b.copyright_text || ''
    ];
    dbutil.sqlinjection(sqldb.MySQLConPool, QRY, params, 'updatewebsitefootersettings', function (err) {
        if (err) {
            console.log('UPDATE WEBSITE FOOTER SETTINGS ERROR:', err);
            return res.json({ status: 500, message: 'Internal server error' });
        }
        return res.json({ status: 200, message: 'Footer settings updated successfully' });
    });
};
// Website Theme Settings - public website branding
exports.getwebsitethemesettings = function (req, res) {
    var QRY = "SELECT id, tenant_id, brand_scope, " +
        "primary_color, secondary_color, sidebar_color, header_color, button_color, " +
        "font_family, custom_css " +
        "FROM tenant_branding " +
        "WHERE tenant_id = ? AND brand_scope = 'public_app' AND IFNULL(d_in,0) = 0 " +
        "ORDER BY id DESC LIMIT 1";

    dbutil.sqlinjection(
        sqldb.MySQLConPool,
        QRY,
        [req.admin.tenant_id],
        'getwebsitethemesettings',
        function (err, rows) {
            if (err) {
                console.log('GET WEBSITE THEME SETTINGS ERROR:', err);
                return res.json({
                    status: 500,
                    message: 'Internal server error'
                });
            }

            return res.json({
                status: 200,
                data: (rows && rows[0]) || {}
            });
        }
    );
};

exports.updatewebsitethemesettings = function (req, res) {
    var b = req.body || {};

    var QRY = "INSERT INTO tenant_branding " +
        "(tenant_id, brand_scope, primary_color, secondary_color, sidebar_color, " +
        "header_color, button_color, font_family, custom_css, d_in) " +
        "VALUES (?, 'public_app', ?, ?, ?, ?, ?, ?, ?, 0) " +
        "ON DUPLICATE KEY UPDATE " +
        "primary_color = VALUES(primary_color), " +
        "secondary_color = VALUES(secondary_color), " +
        "sidebar_color = VALUES(sidebar_color), " +
        "header_color = VALUES(header_color), " +
        "button_color = VALUES(button_color), " +
        "font_family = VALUES(font_family), " +
        "custom_css = VALUES(custom_css), " +
        "d_in = 0";

    var params = [
        req.admin.tenant_id,
        b.primary_color || '#01003c',
        b.secondary_color || '#6c757d',
        b.sidebar_color || '#01003c',
        b.header_color || '',
        b.button_color || '',
        b.font_family || '',
        b.custom_css || ''
    ];

    dbutil.sqlinjection(
        sqldb.MySQLConPool,
        QRY,
        params,
        'updatewebsitethemesettings',
        function (err) {
            if (err) {
                console.log('UPDATE WEBSITE THEME SETTINGS ERROR:', err);
                return res.json({
                    status: 500,
                    message: 'Failed to update website theme settings'
                });
            }

            return res.json({
                status: 200,
                message: 'Website theme settings updated successfully'
            });
        }
    );
};